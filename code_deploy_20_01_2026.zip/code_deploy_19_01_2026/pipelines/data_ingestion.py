import os
import json
from attr import s
from langchain_azure_ai.embeddings import AzureAIEmbeddingsModel
from langchain_azure_ai.chat_models import AzureAIChatCompletionsModel
from azure.core.credentials import AzureKeyCredential
import streamlit as st

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from utils.db_utils import (get_postgres_connection, 
                            insert_data, 
                            create_table_if_not_exist)

from pipelines.loader_pipeline import loader_pipeline
from pipelines.splitter_pipeline import splitter_pipeline


# @st.cache_resource
def get_azureembed(cfg):
    try:
        cred= AzureKeyCredential(os.getenv("AZURE_INFERENCE_KEY"))
        embeddings= AzureAIEmbeddingsModel(
            endpoint= os.getenv('AZURE_INFERENCE_ENDPOINT'), 
            credential=cred, 
            model=cfg['models']['AZURE_EMBED_MODEL']
        )
        return embeddings
    except Exception as e:
        raise e
    

class dataingestion_pipeline:
    def __init__(self, cfg):
        self.cfg= cfg
        self.db_pass= os.getenv("PGSQL_PASS")
        self.splitter= splitter_pipeline(self.cfg)
        self.loader= loader_pipeline(self.cfg)

    def connection_and_table_creation(self):
        conn, curr = get_postgres_connection(self.cfg, self.db_pass)
        flag= create_table_if_not_exist(conn=conn, cursor=curr, 
                                        table_name=self.cfg['database']['table_name'],
                                        schema=self.cfg['database']['schema'])
        if flag:
            print("Table Created Successfully.....")
        else:
            print("Table is not cretaed....")
        return conn, curr

    def main(self):
        embeddings= get_azureembed(self.cfg)
        conn, curr= self.connection_and_table_creation()

        # load the data
        files_list= self.loader.flatten_tree()
        page_ids= [page[0] for page in files_list]
        for page_id in page_ids:
            metadata, page_data= self.loader.load_page(page_id=page_id)
            cleaned_chunks= self.splitter.split_and_clean(html_str=page_data, metadata=metadata) # [[chunk, metadata]]

            # text_chunks= [x[0] for x in cleaned_chunks]

            for _, chunk in enumerate(cleaned_chunks):
                if isinstance(chunk[1], dict):
                    meta= json.dumps(chunk[1])
                else:
                    meta= json.dumps({})
                
                if not chunk[0] == "":
                    # chunk_updated = f"""{chunk[0]} file_details: meeting name: {chunk[1].get('title')} \n meeting date: {chunk[1].get('created_at')}"""
                    vector = embeddings.embed_query(chunk[0])

                    data = {
                        "file_name":  chunk[1].get('title'),
                        "chunk_text": chunk[0],
                        "embedding":vector,
                        "metadata": meta, 
                        "page_id": chunk[1].get('id')
                        }
                    
                    insert_data(
                        conn=conn, cursor=curr, 
                        schema=self.cfg['database']['schema'], 
                        table_name=self.cfg['database']['table_name'],
                        data= data
                    )
                else:
                    pass
            print(f"Processing for file {chunk[1].get('title')} completed....")
