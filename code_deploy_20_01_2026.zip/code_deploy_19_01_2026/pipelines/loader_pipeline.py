from loaders.confluence_loader import ConfluenceLoader
import os

class loader_pipeline:
    def __init__(self, cfg):
        self.PAT= os.getenv("CONFLUENCE_PAT")
        self.cfg= cfg
        self.loader= ConfluenceLoader(base_url=self.cfg['confluence']['BASE_URL'],
                                      pat= self.PAT)
    def _get_child_tree(self):
        parent_id= self.cfg['confluence']['PARENT_ID'] #Parent node id
        print(f"Getting Child Tree for Node: {parent_id}")
        tree= self.loader.build_page_tree(page_id=parent_id, max_depth=2)
        print(f"{parent_id} Node Tree: ", tree)
        return tree
    
    def flatten_tree(self):
        tree= self._get_child_tree()
        self.loader.print_tree(tree) # print tree
        files_list= self.loader.flatten_tree_to_list(node=tree, acc=[])
        return files_list[1:self.cfg['confluence']['PAGES_NO_LIMIT']+1]

    def load_page(self, page_id):
        """
        Docstring for load_page
        
        :param self: Description
        :param page_id: str
        returns:
            metadata: dict
            body: dict
        """
        page = self.loader.get_page(page_id=page_id, 
                             include_body=True)
        metadata= {k:v for k,v in page.items() if k != 'body'}
        body= page.get('body')
        return metadata, body
    
    def main(self):
        files_list= self.flatten_tree()
        
    

        

    
  
  