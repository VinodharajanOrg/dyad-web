import html

from regex import D
from preprocess.chunking import split_html_without_headers
from preprocess.preprocess import clean_docs

## split the HTML documents
## clean the splitted chunks 
## add metadata to every chunk

class splitter_pipeline:
    def __init__(self, cfg):
        self.cfg= cfg
        
    def split_and_clean(self, html_str, metadata):

        if html_str == "":
            return[""]
        
        docs= split_html_without_headers(html_docs=[html_str], 
                                   chunk_size= self.cfg['splitter']['chunk_size'],
                                   chunk_overlap=self.cfg['splitter']['chunk_overlap'])
        
        cleaned_chunks = clean_docs(docs=docs)
        cleaned_chunks= [[x, metadata] for x in cleaned_chunks]
        # [[chunk_1, metadata], [chunk_2, metadata]]
        return cleaned_chunks
    
    