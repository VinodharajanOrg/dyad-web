-- Create MLflow database for tracking
CREATE DATABASE mlflow;

-- Note: pgvector extension is optional and requires separate installation
-- The application uses PostgreSQL's built-in features for vector storage
-- If you need pgvector, use ankane/pgvector image instead

-- Grant necessary permissions
GRANT ALL PRIVILEGES ON DATABASE postgres TO postgres;
GRANT ALL PRIVILEGES ON DATABASE mlflow TO postgres;
