import re
from bs4 import BeautifulSoup

def clean_block_aware_text(html: str) -> str:
    soup = BeautifulSoup(html, "lxml")

    for br in soup.find_all("br"):
        br.replace_with("\n")

    for li in soup.find_all("li"):
        li.insert_before("\n ")

    for t in soup(["script", "style", "noscript"]):
        t.decompose()

    # Use space separator to avoid "GapsSanjoy"
    text = soup.get_text(separator="\n")
    text = text.replace("\xa0", " ")

    # Normalize whitespace:
    text = re.sub(r"\n\s*\n+", "\n\n", text)   # collapse blank lines
    text = re.sub(r"[ \t]+", " ", text)        # collapse spaces
    text = re.sub(r"\s+\n", "\n", text)        # trim spaces before newline
    text = re.sub(r"\n\s+", "\n", text)        # trim spaces after newline
    return text.strip()

def clean_docs(docs:list):
    cleaned_docs= []
    for d in docs:
        cleaned_text= clean_block_aware_text(d.page_content)
        cleaned_docs.append(cleaned_text)
    return cleaned_docs
    

# cleaned_docs= []
# for d in docs:
#     soup = BeautifulSoup(d.page_content, "html.parser")
#     for br in soup.find_all("br"):
#         br.replace_with("\n")