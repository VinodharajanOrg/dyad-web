from langchain_text_splitters import RecursiveCharacterTextSplitter, Language
from typing import Iterable

def split_html_without_headers(
    html_docs: Iterable[str],
    chunk_size: int = 1500,
    chunk_overlap: int = 150,
):
    """
        HTML splitting
        Args:
            html_docs: Iterable of raw HTML strings.
            chunk_size: Max characters per chunk.
            chunk_overlap: Overlap between chunks.

        Returns:
            List[Document]: Documents with page_content; metadata minimal by default.
    """
    splitter = RecursiveCharacterTextSplitter.from_language(
        language=Language.HTML,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )
    return splitter.create_documents(list(html_docs))