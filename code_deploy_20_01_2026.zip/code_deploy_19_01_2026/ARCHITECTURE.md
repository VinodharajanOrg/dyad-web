# RAG Application Architecture

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        Docker Environment                        │
│                                                                   │
│  ┌────────────────┐         ┌─────────────────┐                │
│  │   User Browser │────────▶│  Streamlit App  │                │
│  │                │         │   (Port 8501)   │                │
│  │  localhost:8501│◀────────│                 │                │
│  └────────────────┘         └────────┬────────┘                │
│                                      │                           │
│                                      │ Queries &                │
│                                      │ Embeddings               │
│                                      │                           │
│              ┌───────────────────────┼───────────────────────┐  │
│              │                       │                       │  │
│              ▼                       ▼                       ▼  │
│    ┌──────────────────┐   ┌──────────────────┐   ┌─────────────┐
│    │   PostgreSQL     │   │   MLflow Server  │   │  Azure AI   │
│    │  (Port 5432)     │   │   (Port 5000)    │   │  Services   │
│    │                  │   │                  │   │             │
│    │ • Vector Store   │   │ • Experiment     │   │ • Chat LLM  │
│    │ • Document Chunks│   │   Tracking       │   │ • Embeddings│
│    │ • Embeddings     │   │ • Model Registry │   │             │
│    │ • Metadata       │   │ • Metrics        │   │ (External)  │
│    └──────────────────┘   └──────────────────┘   └─────────────┘
│                                                                   │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │                     Docker Volumes                          │ │
│  │  • postgres_data  - Database persistence                   │ │
│  │  • mlflow_data    - MLflow artifacts                       │ │
│  │  • ./data         - Input/output data (mounted)            │ │
│  └────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────┘
```

## Data Flow

```
1. Document Ingestion Flow:
   ┌──────────┐
   │  .docx   │
   │  Files   │
   └────┬─────┘
        │
        ▼
   ┌────────────────┐
   │  Preprocessing │  • Text extraction
   │  & Chunking    │  • Normalization
   └────┬───────────┘  • Semantic chunking
        │
        ▼
   ┌────────────────┐
   │  Azure AI      │  • Generate embeddings
   │  Embeddings    │  • text-embedding-ada-002
   └────┬───────────┘
        │
        ▼
   ┌────────────────┐
   │  PostgreSQL    │  • Store chunks
   │  Database      │  • Store embeddings
   └────────────────┘  • Store metadata


2. Query & Response Flow:
   ┌──────────────┐
   │  User Query  │
   └──────┬───────┘
          │
          ▼
   ┌──────────────────┐
   │  Generate Query  │  • Embed user query
   │  Embedding       │  • Azure AI
   └──────┬───────────┘
          │
          ├─────────────────────┬──────────────────┐
          ▼                     ▼                  ▼
   ┌─────────────┐      ┌──────────────┐   ┌─────────────┐
   │  Semantic   │      │   Keyword    │   │   MLflow    │
   │  Search     │      │   Search     │   │   Tracking  │
   │  (Vector)   │      │ (Full-Text)  │   └─────────────┘
   └──────┬──────┘      └──────┬───────┘
          │                    │
          └──────────┬─────────┘
                     ▼
              ┌──────────────┐
              │  Combine &   │  • Merge results
              │  Deduplicate │  • Rank by relevance
              └──────┬───────┘
                     │
                     ▼
              ┌──────────────┐
              │   Generate   │  • LLM (gpt-4o-mini)
              │   Response   │  • Context + Query
              └──────┬───────┘
                     │
                     ▼
              ┌──────────────┐
              │   Display    │  • Response
              │   to User    │  • Retrieved chunks
              └──────────────┘
```

## Technology Stack

### Application Layer
- **Streamlit**: Web UI framework
- **LangChain**: LLM orchestration framework
- **Python 3.10**: Runtime environment

### AI/ML Services
- **Azure AI Services**:
  - Chat Model: `gpt-4o-mini`
  - Embedding Model: `text-embedding-ada-002`
- **MLflow**: Experiment tracking and model registry

### Data Layer
- **PostgreSQL 15**: Vector database
  - pgvector extension for similarity search
  - Full-text search capabilities

### Infrastructure
- **Docker**: Containerization
- **Docker Compose**: Multi-container orchestration
- **Docker Volumes**: Data persistence

## Network Architecture

```
Docker Network: rag-network (bridge)
├── postgres:5432      → External: localhost:5432
├── mlflow:5000        → External: localhost:5001
└── rag-app:8501       → External: localhost:8501
```

## Security Considerations

1. **Environment Variables**: Sensitive credentials stored in `.env`
2. **Network Isolation**: Services communicate via internal Docker network
3. **Port Exposure**: Only necessary ports exposed to host
4. **Volume Permissions**: Proper file permissions for mounted volumes

## Scalability Considerations

### Current Architecture (Single Host)
- Good for: Development, small teams, proof of concept
- Limitations: Single point of failure, limited horizontal scaling

### Production Recommendations
1. **Database**: Use managed PostgreSQL (Azure Database, AWS RDS)
2. **MLflow**: Separate tracking server with object storage backend
3. **Application**: Deploy behind load balancer (multiple replicas)
4. **Caching**: Add Redis for session management
5. **Queue**: Add message queue for async processing (Celery + Redis)

## Resource Requirements

### Minimum
- CPU: 2 cores
- RAM: 4GB
- Disk: 10GB

### Recommended
- CPU: 4 cores
- RAM: 8GB
- Disk: 50GB (with data)

### Per Service
```
PostgreSQL: 512MB-1GB RAM
MLflow: 256MB-512MB RAM
RAG App: 1GB-2GB RAM (depending on traffic)
```

## Health Checks

All services include health checks:
- **PostgreSQL**: `pg_isready` command
- **MLflow**: HTTP `/health` endpoint
- **Streamlit**: HTTP `/_stcore/health` endpoint

Health check intervals: 30s
Startup grace period: 30-40s

## Monitoring & Logging

### Logs Location
```bash
# View logs
docker-compose logs -f [service-name]

# Logs are also available in containers
docker exec -it [container-name] tail -f /var/log/...
```

### Metrics
- MLflow UI: Experiment tracking, model metrics
- Docker stats: `docker stats` for resource usage

### Suggested Production Monitoring
- Prometheus + Grafana for metrics
- ELK Stack (Elasticsearch, Logstash, Kibana) for logs
- APM tools (Datadog, New Relic) for application performance
