import os
import ast
import operator
from pydantic import BaseModel, Field
from dotenv import load_dotenv
from typing import TypedDict, Annotated, List, Dict, Optional

from langchain_core.documents import Document
from langchain_core.prompts import PromptTemplate
from langchain_azure_ai.embeddings import AzureAIEmbeddingsModel
from langchain_azure_ai.chat_models import AzureAIChatCompletionsModel
from azure.core.credentials import AzureKeyCredential
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END
from utils.retriever import unique_by_id
from utils.common import read_yaml_config
from utils.retriever import postgres_retriever
from agents.models import QueryAnalysis, RelevanceScore, FinalAnswer, EvaluationResult
from .states import AgentState

from ragas import evaluate
from ragas.metrics import (
    answer_relevancy,
    faithfulness,
    LLMContextPrecisionWithoutReference
)
from datasets import Dataset

# Load environment variables and configuration parameters
load_dotenv()
ENDPOINT = os.getenv("AZURE_INFERENCE_ENDPOINT")
API_KEY = os.getenv("AZURE_INFERENCE_KEY")
cred = AzureKeyCredential(API_KEY)

config = read_yaml_config()
models_config = config.get("models", {})
CHAT_MODEL = models_config.get("AZURE_CHAT_MODEL", "gpt-4o-mini")
EMBED_MODEL = models_config.get("AZURE_EMBED_MODEL", "text-embedding-ada-002")


# Load embedding & Chat model
embeddings = AzureAIEmbeddingsModel(endpoint=ENDPOINT, 
                                    credential=cred, 
                                    model=EMBED_MODEL
                                   )
chat_model = AzureChatOpenAI(
    azure_deployment=CHAT_MODEL,
    api_version="2024-08-01-preview",
    temperature=0, 
    api_key=API_KEY,
    azure_endpoint=ENDPOINT.replace("models", ""))

evaluation_model= chat_model

## Defines Node 
def analyze_query(state: AgentState) -> AgentState:
    """Analyze the user query to understand intent and requirements."""
    
    question = state["question"]
    
    prompt = f"""Analyze this question about meeting data and determine:
1. Query type (single_doc/multi_doc/comparison/aggregation/irrelevant)
2. Whether it requires multiple documents
3. Break it into sub-queries if needed
4. Whether it's relevant to meeting information

Question: {question}

Consider:
- "Who are the participants in all meetings?" → multi_doc, needs all meeting docs
- "Compare budgets discussed in meetings" → comparison, needs multiple docs
- "What did John Smith say in meeting 1?" → single_doc
- "What's the weather today?" → irrelevant

Provide structured analysis."""

    structured_llm = chat_model.with_structured_output(QueryAnalysis)
    analysis = structured_llm.invoke(prompt)
    
    print(f"\nQuery Analysis:")
    print(f"  Type: {analysis.query_type}")
    print(f"  Relevant: {analysis.is_relevant}")
    print(f"  Requires Multiple Docs: {analysis.requires_multiple_docs}")
    print(f"  Sub-queries: {len(analysis.sub_queries)}")
    
    return {
        **state,
        "query_analysis": analysis,
        "sub_queries": analysis.sub_queries if analysis.sub_queries else [question]
    }

def retrieve_documents(state: AgentState) -> AgentState:
    """Retrieve relevant documents based on query analysis."""
    
    query_analysis = state["query_analysis"]
    sub_queries = state["sub_queries"]
    
    if not query_analysis.is_relevant:
        print("\n No retrieval needed - query is irrelevant")
        return state
    
    all_docs = []
    seen_doc_ids = set()
    
    # Retrieve for each sub-query
    for sub_query in sub_queries:
        print(f"\n Retrieving for: {sub_query}")
        
        # docs = retriever.invoke(sub_query)
        docs = postgres_retriever(user_query= sub_query, 
                                  config=config,
                                  password= os.getenv("PGSQL_PASS") ,
                                  embeddings= embeddings)
        # docs= [doc['metadata']= ast.literal_eval(doc.get('metadata')) for doc in docs]
        
        for doc in docs:
            if isinstance(doc.get('metadata'), str):
                doc['metadata'] = ast.literal_eval(doc['metadata'])
                
            doc_id= f"{ast.literal_eval(doc.get('metadata')).get('source_file', 'unknown')}_{doc.get('chunk_text')}"
            # doc_id= f"{doc.get('metadata').get('source_file', 'unknown')}_{doc.get('chunk_text')}"

            if doc_id not in seen_doc_ids:
                all_docs.append(doc)
                seen_doc_ids.add(doc_id)

    print(f"Retrieved {len(all_docs)} unique document chunks")

    # Group by meeting for better visibility
    meetings_found = set()
    for doc in all_docs:
        meeting_name= ast.literal_eval(doc.get('metadata')).get('meeting_name', 'unknown')
        # meeting_name = doc.get('metadata').get('meeting_name', 'unknown')
        meetings_found.add(meeting_name)
    
    print(f"From meetings: {', '.join(sorted(meetings_found))}")
    
    return {
        **state,
        "retrieved_docs": all_docs
    }

def check_relevance(state: AgentState) -> AgentState:
    """Check if retrieved documents are relevant and sufficient."""
    
    question = state["question"]
    docs = state["retrieved_docs"]
    query_analysis = state["query_analysis"]
    
    if not query_analysis.is_relevant:
        return state
        
    doc_context = "\n\n".join([
        f"Document from {doc.get('metadata').get('meeting_name', 'Unknown')} "
        f"({doc.get('metadata').get('meeting_date', 'Unknown date')}) "
        f"[Source: {doc.get('metadata').get('source_file', 'unknown')}]:\n{doc['chunk_text']}"
        for doc in docs[:10]  # Limit context
    ])

    # Get unique meetings covered
    meetings_covered = set()
    for doc in docs:
        # print("Document type\n\n\n\n : ",type(doc))
        meeting_name = doc.get('metadata').get('meeting_name', 'unknown')
        meetings_covered.add(meeting_name)
    
    prompt = f"""Evaluate if these documents can answer the question adequately.

    Question: {question}
    Query Type: {query_analysis.query_type}
    Requires Multiple Docs: {query_analysis.requires_multiple_docs}
    Meetings Covered: {', '.join(sorted(meetings_covered))}

    Documents:
    {doc_context}

    Assess:
    1. Are documents relevant to the question?
    2. Confidence level (0-1)
    3. Do we need more documents? (Consider: Are all mentioned meetings covered? Is information complete?)
    4. Reasoning

    Provide structured assessment."""

    structured_llm = chat_model.with_structured_output(RelevanceScore)
    relevance = structured_llm.invoke(prompt)
    
    print(f"\n Relevance Check:")
    print(f"  Relevant: {relevance.is_relevant}")
    print(f"  Confidence: {relevance.confidence:.2f}")
    print(f"  Needs More: {relevance.needs_more_docs}")
    
    return {
        **state,
        "relevance_score": relevance
    }

# Generate Answer
def generate_answer(state: AgentState) -> AgentState:
    """Generate answer from retrieved documents."""
    
    question = state["question"]
    docs = state["retrieved_docs"]
    query_analysis = state["query_analysis"]
    
    if not query_analysis.is_relevant:
        final_answer = FinalAnswer(
            answer="This question is not relevant to the Given data. Please ask questions about Uploaded docs",
            confidence=1.0,
            sources=[],
            reasoning="Query determined to be irrelevant to meeting information"
        )
        return {
            **state,
            "final_answer": final_answer
        }
    
    # Group documents by meeting (using source file metadata)
    docs_by_meeting = {}
    for doc in docs:
        source_file = doc.get('metadata').get('source_file', 'unknown')
        meeting_name = doc.get('metadata').get('meeting_name', 'Unknown Meeting')
        meeting_date = doc.get('metadata').get('meeting_date', 'Unknown Date')
        
        # Group by meeting name + date (more reliable than source_file alone)
        meeting_key = f"{meeting_name}_{meeting_date}"
        
        if meeting_key not in docs_by_meeting:
            docs_by_meeting[meeting_key] = {
                'name': meeting_name,
                'date': meeting_date,
                'source_files': set(),
                'chunks': []
            }
        
        docs_by_meeting[meeting_key]['source_files'].add(source_file)
        docs_by_meeting[meeting_key]['chunks'].append(doc)
    
    # Prepare context organized by meeting
    context_parts = []
    sources_used = []
    
    for meeting_key, meeting_data in docs_by_meeting.items():
        meeting_name = meeting_data['name']
        meeting_date = meeting_data['date']
        source_files = meeting_data['source_files']
        chunks = meeting_data['chunks']
        
        # Combine all chunks from this meeting
        combined_content = "\n".join([chunk['chunk_text'] for chunk in chunks])
        
        context_parts.append(
            f"=== {meeting_name} ===\n"
            f"Date: {meeting_date}\n"
            f"Source Files: {', '.join(sorted(source_files))}\n"
            f"Content:\n{combined_content}"
        )
        
        sources_used.append(f"{meeting_name} ({meeting_date})")
    
    context = "\n\n".join(context_parts)
    
    prompt = f"""Based on the meeting documents provided, answer the question accurately.

Question: {question}
Query Type: {query_analysis.query_type}

Meeting Documents (from chunked files):
{context}

IMPORTANT INSTRUCTIONS:
- Understand the question first and answer accordingly
- These are CHUNKS from larger meeting documents, identified by their source file footers
- Multiple chunks may belong to the same meeting (same meeting name and date)
- For multi-doc questions (e.g., "all meetings"), synthesize information across ALL meetings shown
- For comparison questions, explicitly compare the different meetings
- For aggregation questions (e.g., "all participants"), combine information from all relevant meetings
- Be specific and cite which meeting(s) you're referring to by meeting name and date
- If information seems incomplete or you only have partial chunks, acknowledge this
- Don't make up information that's not in the chunks

Provide a comprehensive answer with:
1. Direct answer to the question
2. Confidence level (0-1) - lower if chunks seem incomplete
3. Source meetings used (meeting names)
4. Brief reasoning

Be thorough and accurate."""

    structured_llm = chat_model.with_structured_output(FinalAnswer)
    answer = structured_llm.invoke(prompt)
    
    print(f"\nAnswer Generated:")
    print(f"  Confidence: {answer.confidence:.2f}")
    print(f"  Sources: {', '.join(answer.sources)}")
    
    return {
        **state,
        "final_answer": answer,
        "current_answer": answer.answer
    }


def evaluate_answer(state: AgentState) -> AgentState:
    """
    Evaluate the generated answer using RAGAS (no reference dataset).
    """

    question = state["question"]
    final_answer = state["final_answer"]
    docs = state["retrieved_docs"]

    print("\n\n\n\n\n\n\n\n")
    print(question)
    print(final_answer)
    print(docs)
    print("\n\n\n\n\n\n\n\n")

    if final_answer is None or not docs:
        print("Skipping evaluation (no answer or docs)")
        return state

    # Ensure contexts is a list of strings
    contexts = [doc["chunk_text"] for doc in docs]

    # Create RAGAS-compatible dataset
    data = Dataset.from_dict({
        "question": [question],
        "answer": [getattr(final_answer, 'answer', final_answer)], # Safety check for object vs string
        "contexts": [contexts]
    })

    print("\n Running RAGAS Evaluation...")

    # Initialize the metric explicitly if needed
    context_precision_metric = LLMContextPrecisionWithoutReference()

    result = evaluate(
        dataset=data,
        metrics=[
            answer_relevancy,
            context_precision_metric,
            faithfulness
        ],
        llm=evaluation_model,
        embeddings=embeddings
    )

    # Convert to pandas to see the actual column names generated
    df_result = result.to_pandas()
    scores = df_result.iloc[0].to_dict()
    

    precision_score = scores.get("llm_context_precision_without_reference", 
                                scores.get("context_precision", 0.0))

    evaluation = EvaluationResult(
        answer_relevancy=scores.get("answer_relevancy", 0.0),
        context_precision=precision_score,
        faithfulness=scores.get("faithfulness", 0.0),
        reasoning={
            "answer_relevancy": "Checks if the answer addresses the question",
            "context_precision": "Measures if the retrieved chunks are relevant to the answer",
            "faithfulness": "Verifies if the answer is derived ONLY from the contexts"
        }
    )

    print(f"  Relevancy      : {evaluation.answer_relevancy:.2f}")
    print(f"  Precision      : {evaluation.context_precision:.2f}")
    print(f"  Faithfulness   : {evaluation.faithfulness:.2f}")

    return {
        **state,
        "evaluation_result": evaluation
    }

## Should continue function 
def should_continue(state: AgentState) -> str:
    """Decide whether to continue retrieval or end."""
    
    query_analysis = state.get("query_analysis")
    
    # If query is irrelevant, skip to answer
    if query_analysis and not query_analysis.is_relevant:
        return "generate_answer"
    
    relevance = state.get("relevance_score")
    iteration = state.get("iteration", 0)
    max_iterations = state.get("max_iterations", 3)
    
    # If no relevance check yet, continue to check
    if relevance is None:
        return "check_relevance"
    
    # If documents are good enough or max iterations reached, generate answer
    if relevance.is_relevant and relevance.confidence > 0.7:
        return "generate_answer"
    
    if iteration >= max_iterations:
        print(f"\nMax iterations ({max_iterations}) reached")
        return "generate_answer"
    
    if relevance.needs_more_docs and iteration < max_iterations:
        print(f"\nIteration {iteration + 1}: Retrieving more documents")
        return "retrieve_more"
    
    return "generate_answer"

## retrieve more docs 
def retrieve_more_documents(state: AgentState) -> AgentState:
    """Retrieve additional documents with refined queries."""
    
    iteration = state.get("iteration", 0)
    
    # Increase retrieval parameters, Try broader queries
    # new_retriever = vectorstore.as_retriever(
    #     search_kwargs={"k": 8 + (iteration * 2)}
    # )
    

    question = state["question"]
    docs = postgres_retriever(user_query=question, config=config, 
                              password=os.getenv("PGSQL_PASS"), embeddings=embeddings)
    print(f"  Retrieved {len(docs)} additional chunks")
    
    return {
        **state,
        "retrieved_docs": state["retrieved_docs"] + docs,
        "iteration": iteration + 1
    }

## Design the graph
def create_agentic_rag():
    workflow = StateGraph(AgentState)

    workflow.add_node("analyze_query", analyze_query)
    workflow.add_node("retrieve_documents", retrieve_documents)
    workflow.add_node("check_relevance", check_relevance)
    workflow.add_node("generate_answer", generate_answer)
    workflow.add_node("evaluate_answer", evaluate_answer)
    workflow.add_node("retrieve_more", retrieve_more_documents)

    workflow.set_entry_point("analyze_query")

    workflow.add_edge("analyze_query", "retrieve_documents")
    workflow.add_edge("retrieve_documents", "check_relevance")

    workflow.add_conditional_edges(
        "check_relevance",
        should_continue,
        {
            "generate_answer": "generate_answer",
            "retrieve_more": "retrieve_more"
        }
    )

    workflow.add_edge("retrieve_more", "check_relevance")
    workflow.add_edge("generate_answer", "evaluate_answer")
    workflow.add_edge("evaluate_answer", END)

    return workflow.compile()
