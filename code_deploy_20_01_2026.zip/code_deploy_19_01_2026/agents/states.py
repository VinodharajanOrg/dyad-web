import operator
from typing import TypedDict, Annotated, List, Dict, Optional
from .models import QueryAnalysis, FinalAnswer, RelevanceScore, EvaluationResult
from langchain_core.documents import Document

## Agent States

class AgentState(TypedDict):
    question: str
    query_analysis: Optional[QueryAnalysis]
    sub_queries: List[str]
    retrieved_docs: Annotated[List[Document], operator.add]
    relevance_score: Optional[RelevanceScore]
    current_answer: str
    final_answer: Optional[FinalAnswer]
    evaluation_result: Optional[EvaluationResult]
    iteration: int
    max_iterations: int
