from pydantic import BaseModel, Field
from typing import TypedDict, Annotated, List, Dict, Optional


class QueryAnalysis(BaseModel):
    """Analysis of the user query."""
    query_type: str = Field(description="Type: 'single_doc', 'multi_doc', 'comparison', 'aggregation', or 'irrelevant'")
    requires_multiple_docs: bool = Field(description="Whether query needs multiple documents")
    sub_queries: List[str] = Field(description="Broken down sub-queries if needed")
    is_relevant: bool = Field(description="Whether query is relevant to meeting data")
    reasoning: str = Field(description="Reasoning for the analysis")

class RelevanceScore(BaseModel):
    """Relevance scoring for retrieved documents."""
    is_relevant: bool = Field(description="Whether documents are relevant")
    confidence: float = Field(description="Confidence score 0-1")
    reasoning: str = Field(description="Reasoning for the score")
    needs_more_docs: bool = Field(description="Whether more documents are needed")

class FinalAnswer(BaseModel):
    """Final answer with confidence."""
    answer: str = Field(description="The final answer")
    confidence: float = Field(description="Confidence in answer 0-1")
    sources: List[str] = Field(description="Source meeting IDs used")
    reasoning: str = Field(description="Reasoning process")


class EvaluationResult(BaseModel):
    answer_relevancy: float = Field(description="How relevant the answer is to the question (0-1)")
    context_precision: float = Field(description="Signal-to-noise ratio of retrieved context (0-1)")
    faithfulness: float = Field(description="Hallucination score – is answer grounded in context (0-1)")
    reasoning: Dict[str, str] = Field(description="LLM reasoning per metric")


