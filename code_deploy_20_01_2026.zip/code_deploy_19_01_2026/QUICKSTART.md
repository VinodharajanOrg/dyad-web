# Quick Start: Running RAG Application in Docker

## 🚀 Fastest Way to Get Started

### 1️⃣ Setup Environment (One-time)

```bash
# Copy environment template
cp .env.example .env

# Edit .env and add your Azure credentials
nano .env  # or use your favorite editor
```

Required variables in `.env`:
- `AZURE_INFERENCE_ENDPOINT` - Your Azure AI endpoint
- `AZURE_INFERENCE_KEY` - Your Azure API key
- `PGSQL_PASS` - PostgreSQL password (default: postgres)

### 2️⃣ Start Everything

```bash
# Using the helper script (recommended)
./docker-helper.sh start

# OR using docker-compose directly
docker-compose up -d --build
```

### 3️⃣ Access Applications

- **Streamlit App**: http://localhost:8501
- **MLflow UI**: http://localhost:5001

### 4️⃣ Ingest Your Data

1. Place `.docx` files in `data/input_data/`
2. Open http://localhost:8501
3. Click "Ingest Data" in the sidebar

### 5️⃣ Start Chatting! 🎉

Ask questions about your documents in the chat interface.

---

## 📝 Common Commands

```bash
# View all services status
./docker-helper.sh status

# View logs
./docker-helper.sh logs          # All services
./docker-helper.sh logs rag-app  # Specific service

# Restart services
./docker-helper.sh restart

# Run tests
./docker-helper.sh test

# Stop everything
./docker-helper.sh stop
```

---

## 🔧 Troubleshooting

### Services Won't Start?
```bash
# Check logs
./docker-helper.sh logs

# Rebuild everything
docker-compose down
docker-compose up -d --build
```

### Can't Connect to Database?
```bash
# Check if PostgreSQL is running
docker-compose ps postgres

# View database logs
./docker-helper.sh logs postgres
```

### Port Already in Use?
```bash
# Find what's using port 8501
lsof -i :8501  # macOS/Linux
netstat -ano | findstr :8501  # Windows

# Kill the process or change port in docker-compose.yml
```

---

## 📖 Full Documentation

See [DOCKER_SETUP.md](DOCKER_SETUP.md) for complete documentation including:
- Architecture details
- Production deployment
- Backup/restore procedures
- Advanced troubleshooting

---

## 🛑 Stopping & Cleanup

```bash
# Stop services (keeps data)
./docker-helper.sh stop

# Remove everything including data
./docker-helper.sh cleanup
```
