
import os
import pytest
import psycopg2
from dotenv import load_dotenv
from ..utils.db_utils import (get_postgres_connection, create_table_if_not_exist, 
                            insert_data)


# Load environment variables
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), "..", ".env"))

@pytest.fixture(scope="session")
def db_config():
    return {
        "database": {
            "host": "localhost",
            "port": 5432,
            "dbname": "postgres",
            "user": "postgres",
            "table_name": "unit_test",
            "schema": "unit_test"
        }
    }

@pytest.fixture(scope="session")
def db_password():
    return os.getenv('PGSQL_PASS')

@pytest.fixture(scope="session")
def db_conn(db_config, db_password):
    """Create DB connection once per test session."""
    conn = psycopg2.connect(
        host=db_config["database"]["host"],
        port=db_config["database"]["port"],
        dbname=db_config["database"]["dbname"],
        user=db_config["database"]["user"],
        password= db_password
    )
    cursor = conn.cursor()

    yield conn, cursor

    cursor.close()
    conn.close()


@pytest.fixture(scope="session")
def mock_data():
    return  [ {
                "file_name": "doc_alpha.docx",
                "chunk_text": "Introduction to the payment system architecture and key components.",
                "embedding": [0.12, 0.34, 0.56, 0.22],
                "metadata": { "page": 1, "section": "Introduction" }
                    },
                    {
                        "file_name": "doc_alpha.docx",
                        "chunk_text": "The transaction lifecycle includes authorization, clearing, and settlement.",
                        "embedding": [0.09, 0.41, 0.58, 0.27],
                        "metadata": { "page": 2, "section": "Lifecycle" }
                    },
                    {
                        "file_name": "doc_alpha.docx",
                        "chunk_text": "Security controls such as tokenization and encryption protect cardholder data.",
                        "embedding": [0.31, 0.28, 0.47, 0.15],
                        "metadata": { "page": 3, "section": "Security" }
                    },
                    {
                        "file_name": "doc_alpha.docx",
                        "chunk_text": "Latency targets require optimizing network hops and batching strategies.",
                        "embedding": [0.22, 0.18, 0.63, 0.11],
                        "metadata": { "page": 4, "section": "Performance" }
                    },

                    {
                        "file_name": "doc_beta.docx",
                        "chunk_text": "Merchant onboarding involves KYC verification and agreement execution.",
                        "embedding": [0.44, 0.12, 0.33, 0.29],
                        "metadata": { "page": 1, "section": "Onboarding" }
                    }
        ]