import os
import pytest
import psycopg2
import numpy as np
from dotenv import load_dotenv
from utils.db_utils import semantic_retrieve_data

def test_retrievr(db_config, 
                  db_conn, 
                  mock_data):
    top_k=3
    conn, cursor = db_conn
    dummy_query_embedding = mock_data[0]['embedding'] 

    ref_chunk = mock_data[0]['chunk_text'] 
    # "Introduction to the payment system architecture and key components." 
    # mock_data[0]['chunk_text']
    top_chunks= semantic_retrieve_data(cursor, db_config['database']['schema'], 
                                       db_config['database']['table_name'],
                                         query_embedding= dummy_query_embedding, 
                                         top_k=top_k
                                         )
    
    assert len(top_chunks) > 1   #Are we getting retrieved chunks?
    assert len(top_chunks) == top_k 
    assert ref_chunk in [itm['chunk_text'] for itm in top_chunks ] #check relevancy

def test_retriever_with_empty_embedding_list(db_config, db_conn):
    with pytest.raises(ValueError):
        top_k=3
        conn, cursor = db_conn
        empty_embedding_list=[]
        top_chunks= semantic_retrieve_data(cursor, db_config['database']['schema'], db_config['database']['table_name'], query_embedding= empty_embedding_list, top_k=top_k)
        

