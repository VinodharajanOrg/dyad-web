from preprocess.chunking import get_chunks


def test_get_chunks_basic():
    text = "\n\n".join(["Heading", "This is a paragraph.", "Another paragraph."])
    chunks = get_chunks(text, chunk_size=50, chunk_overlap=5)
    assert isinstance(chunks, list)
    assert len(chunks) >= 1
    assert all(isinstance(c, str) for c in chunks)

def test_chunking_on_empty_str():
    text = ""
    chunks = get_chunks(text, chunk_size=50, chunk_overlap=5)
    assert chunks == []
   
   

 