import os
import pytest
import json
import psycopg2
from dotenv import load_dotenv
from utils.common import read_yaml_config
from utils.db_utils import (get_postgres_connection, create_table_if_not_exist, 
                            insert_data)


@pytest.fixture
def get_connection():
    return get_postgres_connection

@pytest.fixture
def get_table_created():
    return create_table_if_not_exist


def test_check_connection(db_config, 
                          get_connection, 
                          db_password
                          ):
    CONFIG= db_config
    conn, cursor = get_connection(db_config,
                                  db_password
                                  )
    # If you actually connect to a real DB, these will be psycopg2 types
    assert isinstance(conn, psycopg2.extensions.connection)
    assert isinstance(cursor, psycopg2.extensions.cursor)


def test_create_table(db_config,
                       get_connection, 
                       db_password
                       ):
    CONFIG= db_config
    conn, cursor = get_connection(db_config, 
                                  db_password
                                  )
    output = create_table_if_not_exist(conn, cursor, 
                                       db_config['database']['table_name'],
                                        db_config['database']['schema'])
    assert output == True

def test_duplicate_data_insertion(mock_data, db_config, 
                                  get_connection,
                                    get_table_created,
                                    db_password):
    schema= db_config['database']['schema']
    table_name= db_config['database']['table_name']
    conn, cursor = get_connection(db_config, db_password)

    output = get_table_created(conn, cursor, table_name, schema)

    unique_data_count= len(mock_data)
    duplicated_mock_data= mock_data*4 

    
    for record in duplicated_mock_data:
      record['metadata']= json.dumps(record['metadata'])
      insert_data(conn, cursor, schema, table_name, record)
      
    # fetch wall and find out the counts
    qualified_table = f"{schema}.{table_name}"
    query = f"SELECT COUNT(*) FROM {qualified_table};"
    cursor.execute(query)
    record_count = cursor.fetchone()[0]
    assert record_count != 0 
    assert record_count == unique_data_count

