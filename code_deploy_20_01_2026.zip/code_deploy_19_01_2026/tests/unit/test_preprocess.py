from types import SimpleNamespace
from preprocess.preprocess import table_to_json_str, final_process, preprocessing_main
import json
from docx import Document


def make_doc(paragraphs=None, tables=None):
    paragraphs = paragraphs or []
    tables = tables or []

    # Create simple paragraph-like objects
    doc_paragraphs = []
    p_map = []
    for text, style_name in paragraphs:
        p = SimpleNamespace(text=text, style=SimpleNamespace(name=style_name))
        # Create underlying _p placeholder so identity matching works
        p._p = object()
        doc_paragraphs.append(p)
        p_map.append(p)

    # Create simple table-like objects
    doc_tables = []
    for rows in tables:
        # rows is list of lists (cells texts)
        cells_rows = []
        for r in rows:
            # each row has .cells list with .text
            class Cell:
                def __init__(self, txt):
                    self.text = txt
            class Row:
                def __init__(self, cells):
                    self.cells = [Cell(c) for c in cells]
            cells_rows.append(Row(r))
        t = SimpleNamespace(rows=cells_rows)
        t._tbl = object()
        doc_tables.append(t)

    # Build an element.body.iterchildren structure where we interleave CT_P and CT_Tbl placeholders
    # We'll use simple sentinel objects for CT_P and CT_Tbl and ensure _p/_tbl mapping finds paragraphs/tables
    CT_P = type('CT_P', (), {})
    CT_Tbl = type('CT_Tbl', (), {})

    # Build children: paragraphs then tables
    children = []
    # We'll map each paragraph's _p to the corresponding child to allow final_process to match them
    for p in doc_paragraphs:
        child = CT_P()
        # attach same identity
        child._p = p._p
        children.append(child)

    for t in doc_tables:
        child = CT_Tbl()
        child._tbl = t._tbl
        children.append(child)

    # Create doc with properties used by functions
    doc = SimpleNamespace(
        paragraphs=doc_paragraphs,
        tables=doc_tables,
        element=SimpleNamespace(body=SimpleNamespace(iterchildren=lambda: children))
    )
    return doc


def test_table_to_json_str_empty():
    class T:
        rows = []
    assert table_to_json_str(T()) == "[]"



def test_table_to_json_str():
    doc = Document()
    table= doc.add_table(rows=2, cols=2)

    table.rows[0].cells[0].text = "project"
    table.rows[0].cells[1].text = "Team members"
    table.rows[1].cells[0].text = "RAG"
    table.rows[1].cells[1].text = "2"

    json_str= table_to_json_str(table)
    data= json.loads(json_str)

    assert isinstance(data, list)
    assert data[0]['project'] == "RAG"
    assert data[0]['Team members'] == "2"



def test_final_process_headings_and_para():
    doc= Document()
    
    heading= "Sample heading"
    content= "This is a content text.."

    doc.add_heading(heading, level=1)
    doc.add_paragraph(content)

    output = final_process(doc)

    assert heading in output 
    assert content in output

# def test_table_to_json_str_normal():
#     # header + 2 rows
#     rows = [
#         ["col1", "col2"],
#         ["a", "b"],
#         ["c", "d"]
#     ]
#     class Table:
#         def __init__(self, rows):
#             self.rows = [type('R', (), { 'cells': [type('C', (), {'text': v})() for v in row]})() for row in rows]
    
#     t = Table(rows)
#     s = table_to_json_str(t)

#     data = json.loads(s)
  
#     assert isinstance(data, list)
#     assert data[0]["col1"] == "a"
