from app import embeddings
import pytest

@pytest.fixture
def get_model():
    model= embeddings
    return model

## Emmbedding quality: without doing result comparison 
def test_embed_query_returns_vector(get_model):
    emb= get_model.embed_query("Hi")
    assert type(emb) == list
    assert len(emb) == 1536

def test_embed_documents_returns_vector_list(get_model):
    docs= ["AI is a advance tech.", 
           "This file is about the unit test of embedding"]
    output = get_model.embed_documents(docs)

    assert isinstance(output, list) #output format should be list
    assert len(output) == 2  # should return 2 list [ [1], [2] ]
    assert len(docs) == len(output)
    for emb in output:
        assert hasattr(emb, "__iter__") #output type must be iterable 
        assert all(isinstance(x, (int, float)) for x in emb)
        assert len(emb) > 1

