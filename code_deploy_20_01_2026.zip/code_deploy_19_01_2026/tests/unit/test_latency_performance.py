import time
import pytest
import os
from app import ingest_data, embeddings
from utils.db_utils import semantic_retrieve_data

data_directory= os.path.join('tests', 'data')

db_config =  {
        "database": {
            "host": "localhost",
            "port": 5432,
            "dbname": "postgres",
            "user": "postgres",
            "table_name": "latency_test",
            "schema": "testing1234"
        }
    }

schema= "testing1234"

def test_ingestion_latency(db_conn):
    conn, cursor= db_conn
    cursor.execute(f'DROP SCHEMA IF EXISTS "{schema}" CASCADE;')
    conn.commit()

    start = time.perf_counter()
    ingest_data(dir_path = data_directory, config=db_config)
    latency = time.perf_counter() - start
    print(f"Data Ingestion Latency: {latency} Sec.")
    assert latency < 5 , f"Ingestion process too slow: {latency:.4f}s"


def test_retrieval_latency(db_conn):
    top_k=3
    conn, cursor= db_conn
    query= "who is the project manager?"
    start = time.perf_counter()

    query_emb= embeddings.embed_query(query)
    chunks = semantic_retrieve_data(cursor, db_config['database']['schema'], 
                           db_config['database']['table_name'], 
                   query_embedding= query_emb, top_k=top_k)
    
    latency = time.perf_counter() - start
    print(f"Retrieval process Latency for single record: {latency} Sec.")
    assert latency < 4, f"Retriever too slow: {latency:.4f}s"

