## Process

### 🐳 Docker Setup (Recommended)

The easiest way to run this application is using Docker. See [QUICKSTART.md](QUICKSTART.md) for a quick guide or [DOCKER_SETUP.md](DOCKER_SETUP.md) for full documentation.

```bash
# Quick start with Docker
cp .env.example .env  # Edit with your credentials
./docker-helper.sh start
```

Access the application at http://localhost:8501

---

### 💻 Local Development Setup

#### Create the env 

```bash 

#Create env using python 
$ python -m venv .venv 

#Activate the env 
$./.venv/Scripts/activate 

## Create env using .uv 

$ uv init

```
#### Install the requirements 
```bash
$ uv sync  # it will install the requirements from pyproject.toml file

# if you created env using .uv 
$ pip install -r requirements.txt
```
#### Configs & Security keys 

```bash 
## put the required datbase config details in config.yaml file 
## For local dev, use config.local.yml with host: "localhost"

## create .env file and mention your all secret keys in it (refer .env.example file)

```
#### To Run the project 
```bash
$ mlflow ui #to run mlflow server -- (step-1)
$ streamlit run app.py #to run rag app --(step-2)
```

#### To run tests 
```bash

# step 1: make sure mlflow server is up and running before the tests

$ mlflow ui

# step 2: to run any specific test file use below command
$ python -m pytest tests/<your-test-case-name>

# example 
$ python -m pytest tests/unit/test_embedding.py

# step 3: To run all the test cases
$ python -m pytest


```

