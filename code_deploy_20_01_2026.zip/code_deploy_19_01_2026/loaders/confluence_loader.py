import time
from datetime import datetime, timezone
from urllib.parse import urlparse, parse_qs
import requests
from .confluence_exceptions import (
                    ConfluenceError,
                    ConfluenceAuthError,
                    ConfluenceNotFound,
                    ConfluenceRateLimited,
                    ConfluenceServerError
                )
from dotenv import load_dotenv

load_dotenv()

def _parse_data(dt: str | None) -> str | None:
    """
    Normalize Confluence timestamps to ISO 8601 (UTC) strings.
    Returns None if input is None; returns raw string if parsing fails.
    """
    if not dt:
        return None
    try:
        # Normalize 'Z' (Zulu) to explicit UTC offset for fromisoformat
        if dt.endswith('Z'):
            dt_obj = datetime.fromisoformat(dt.replace('Z', '+00:00'))
        else:
            dt_obj = datetime.fromisoformat(dt)
        return dt_obj.astimezone(timezone.utc).isoformat()
    except Exception:
        return dt


class ConfluenceLoader:
    """
    Simple Confluence loader using:
      - Bearer PAT in headers
      - requests.get(..., verify=False)
    """

    def __init__(self, base_url: str, pat: str, 
                 timeout_sec: int = 30, 
                 max_retries: int = 2, 
                 backoff_sec: float = 1.5):
        if not base_url.endswith("/"):
            base_url += "/"
        self.base_url = base_url
        self.headers = {
            "Authorization": f"Bearer {pat}",
            "Accept": "application/json",
            "User-Agent": "ConfluenceLoaderSimple/1.1",
        }
        self.timeout_sec = timeout_sec
        self.max_retries = max_retries
        self.backoff_sec = backoff_sec

    def _get(self, path: str, params: dict | None = None):
        url = self.base_url + path.strip("/")

        last_exc: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                resp = requests.get(
                    url,
                    headers=self.headers,
                    params=params,
                    timeout=self.timeout_sec,
                    verify=False,  # NOTE: consider True in prod with proper CA
                )

                if 200 <= resp.status_code < 300:
                    return resp

                # status handling
                if resp.status_code in (401, 403):
                    raise ConfluenceAuthError(f"Auth failed ({resp.status_code}). Check PAT permissions. URL={url}")
                if resp.status_code == 404:
                    raise ConfluenceNotFound(f"Resource not found (404). URL={url}")

                if resp.status_code == 429:
                    # Rate limit: honor Retry-After if present
                    retry_after = float(resp.headers.get("Retry-After", self.backoff_sec))
                    if attempt < self.max_retries:
                        time.sleep(retry_after)
                        continue
                    raise ConfluenceRateLimited(f"Rate limited (429). Retries exhausted. URL={url}")

                if 500 <= resp.status_code < 600:
                    if attempt < self.max_retries:
                        time.sleep(self.backoff_sec * (attempt + 1))
                        continue
                    raise ConfluenceServerError(f"Server error {resp.status_code} after retries. URL={url}")

                resp.raise_for_status()

            except (requests.Timeout, requests.ConnectionError) as e:
                last_exc = e
                if attempt < self.max_retries:
                    time.sleep(self.backoff_sec * (attempt + 1))
                    continue
                raise ConfluenceError(f"Network error after retries: {e}") from e
            except requests.RequestException as e:
                raise ConfluenceError(f"HTTP error: {e}") from e

        # Fallback
        if last_exc:
            raise ConfluenceError(f"Request failed: {last_exc}")
        raise ConfluenceError("Unknown request failure")

    # 1) Get single page (optional body) + created/updated metadata
    def get_page(self, page_id: str, include_body: bool = False) -> dict:
        # We want updated (version) and created (history)
        expands = ["version", "history"]
        if include_body:
            expands.append("body.storage")

        params = {"expand": ",".join(expands)}
        resp = self._get(f"rest/api/content/{page_id}", params=params)

        try:
            data = resp.json()
        except ValueError as e:
            raise ConfluenceError(f"Invalid JSON while reading page {page_id}") from e

        links = data.get("_links") or {}
        base = links.get("base")
        webui = links.get("webui")
        web_url = (base + webui) if (base and webui) else webui

        version = data.get("version") or {}
        history = data.get("history") or {}

        return {
            "id": data.get("id"),
            "title": data.get("title"),
            "spaceKey": (data.get("space") or {}).get("key"),
            "webUrl": web_url,
            "version": version.get("number"),
            "updated_at": _parse_data(version.get("when")),
            "updated_by": ((version.get("by") or {}).get("displayName")
                           or (version.get("by") or {}).get("publicName")
                           or (version.get("by") or {}).get("username")),
            "created_at": _parse_data(history.get("createdDate")),
            "created_by": ((history.get("createdBy") or {}).get("displayName")
                           or (history.get("createdBy") or {}).get("publicName")
                           or (history.get("createdBy") or {}).get("username")),
            "body": ((data.get("body") or {}).get("storage") or {}).get("value") if include_body else None,
        }

    def list_pages(self, limit: int = 50):
        # Pull minimal metadata + last updated info without page bodies
        params = {
            "type": "page",
            "limit": max(1, min(limit, 200)),
            "expand": "version",
        }
        path = "rest/api/content"

        while True:
            resp = self._get(path, params=params)
            try:
                data = resp.json()
            except ValueError as e:
                raise ConfluenceError("Invalid JSON while listing pages") from e

            for item in data.get("results", []):
                version = item.get("version") or {}
                yield {
                    "id": item.get("id"),
                    "title": item.get("title"),
                    "spaceKey": (item.get("space") or {}).get("key"),
                    "version": version.get("number"),
                    "updated_at": _parse_data(version.get("when")),
                    "updated_by": ((version.get("by") or {}).get("displayName")
                                   or (version.get("by") or {}).get("publicName")
                                   or (version.get("by") or {}).get("username")),
                }

            next_rel = (data.get("_links") or {}).get("next")
            if not next_rel:
                break

            q = parse_qs(urlparse(next_rel).query)
            for k, v in q.items():
                params[k] = v[0] if isinstance(v, list) and v else v

    # List Pages in space
    def list_pages_in_space(self, space_key: str, limit: int = 50):
        params = {
            "type": "page",
            "spaceKey": space_key,
            "limit": max(1, min(limit, 200)),
            "expand": "version",
        }
        path = "rest/api/content"

        while True:
            resp = self._get(path, params=params)
            try:
                data = resp.json()
            except ValueError as e:
                raise ConfluenceError(f"Invalid JSON while listing space={space_key}") from e

            for item in data.get("results", []):
                version = item.get("version") or {}
                yield {
                    "id": item.get("id"),
                    "title": item.get("title"),
                    "spaceKey": space_key,
                    "version": version.get("number"),
                    "updated_at": _parse_data(version.get("when")),
                    "updated_by": ((version.get("by") or {}).get("displayName")
                                   or (version.get("by") or {}).get("publicName")
                                   or (version.get("by") or {}).get("username")),
                }

            next_rel = (data.get("_links") or {}).get("next")
            if not next_rel:
                break

            q = parse_qs(urlparse(next_rel).query)
            for k, v in q.items():
                params[k] = v[0] if isinstance(v, list) and v else v

    # 4) Children of a page (no recursion)
    def get_children_pages(self, parent_id: str, limit: int = 200) -> list[dict]:
        params = {"limit": max(1, min(limit, 200))}
        resp = self._get(f"rest/api/content/{parent_id}/child/page", params=params)

        try:
            data = resp.json()
        except ValueError as e:
            raise ConfluenceError(f"Invalid JSON while listing children for {parent_id}") from e

        return [{"id": item.get("id"), "title": item.get("title")} for item in data.get("results", [])]
    
    # 5) Build page tree (recursive)
    def build_page_tree(self, page_id: str, max_depth: int | None = None) -> dict:
        root = self.get_page(page_id, include_body=False)
        node = {"id": root["id"], "title": root["title"], "children": []}

        if max_depth == 0:
            return node

        try:
            children = self.get_children_pages(page_id)
        except ConfluenceNotFound:
            return node

        for child in children:
            node["children"].append(
                self.build_page_tree(
                    child["id"],
                    None if max_depth is None else max_depth - 1,
                )
            )
        return node

    def flatten_tree_to_list(self, node: dict, acc: list) -> list:
        """
        Recursively flatten the tree into a list of [id, title].
        """
        acc.append([node.get("id"), node.get("title")])
        for child in node.get("children", []):
            self.flatten_tree_to_list(child, acc)
        return acc
    
    @staticmethod
    def print_tree(node: dict, indent: int = 0) -> None:
        print("  " * indent + f"- {node.get('title', '(no title)')} (id={node.get('id')})")
        for child in node.get("children", []):
            ConfluenceLoader.print_tree(child, indent + 1)



# class ConfluenceLoader:
#     """
#      Confluence loader using:
#       - Bearer PAT in headers
#       - requests.get(..., verify=False)
#     """

#     def __init__(self, base_url: str, pat: str, 
#                  timeout_sec: int = 30, 
#                  max_retries: int = 2, 
#                  backoff_sec: float = 1.5):
#         if not base_url.endswith("/"):
#             base_url += "/"
#         self.base_url = base_url
#         self.headers = {
#             "Authorization": f"Bearer {pat}",
#             "Accept": "application/json",
#             "User-Agent": "ConfluenceLoaderSimple/1.1",
#         }
#         self.timeout_sec = timeout_sec
#         self.max_retries = max_retries
#         self.backoff_sec = backoff_sec

#     def _get(self, path: str, params: dict | None = None):
#         url = self.base_url + path.lstrip("/")
#         last_exc: Exception | None = None

#         for attempt in range(self.max_retries + 1):
#             try:
#                 resp = requests.get(
#                     url,
#                     headers=self.headers,
#                     params=params,
#                     timeout=self.timeout_sec,
#                     verify=False,
#                 )

#                 if 200 <= resp.status_code < 300:
#                     return resp

#                 # status handling
#                 if resp.status_code in (401, 403):
#                     raise ConfluenceAuthError(f"Auth failed ({resp.status_code}). Check PAT permissions. URL={url}")
#                 if resp.status_code == 404:
#                     raise ConfluenceNotFound(f"Resource not found (404). URL={url}")

#                 if resp.status_code == 429:
#                     # Rate limit:
#                     retry_after = float(resp.headers.get("Retry-After", self.backoff_sec))
#                     if attempt < self.max_retries:
#                         time.sleep(retry_after)
#                         continue
#                     raise ConfluenceRateLimited(f"Rate limited (429). Retries exhausted. URL={url}")

#                 if 500 <= resp.status_code < 600:
#                     if attempt < self.max_retries:
#                         time.sleep(self.backoff_sec * (attempt + 1))
#                         continue
#                     raise ConfluenceServerError(f"Server error {resp.status_code} after retries. URL={url}")
#                 resp.raise_for_status()

#             except (requests.Timeout, requests.ConnectionError) as e:
#                 last_exc = e
#                 if attempt < self.max_retries:
#                     time.sleep(self.backoff_sec * (attempt + 1))
#                     continue
#                 raise ConfluenceError(f"Network error after retries: {e}") from e
#             except requests.RequestException as e:
#                 raise ConfluenceError(f"HTTP error: {e}") from e

#         if last_exc:
#             raise ConfluenceError(f"Request failed: {last_exc}")
#         raise ConfluenceError("Unknown request failure")

  
#     # get single page body
#     def get_page(self, page_id: str, include_body: bool = False) -> dict:
#         params = {"expand": "body.storage"} if include_body else None
#         resp = self._get(f"rest/api/content/{page_id}", params=params)

#         try:
#             data = resp.json()
#         except ValueError as e:
#             raise ConfluenceError(f"Invalid JSON while reading page {page_id}") from e

#         return {
#             "id": data.get("id"),
#             "title": data.get("title"),
#             "spaceKey": (data.get("space") or {}).get("key"),
#             "webUrl": (data.get("_links") or {}).get("webui"),
#             "body": ((data.get("body") or {}).get("storage") or {}).get("value") if include_body else None,
#         }

#     def list_pages(self, limit: int = 50):
#         params = {"type": "page", "limit": max(1, min(limit, 200))}
#         path = "rest/api/content"

#         while True:
#             resp = self._get(path, params=params)
#             try:
#                 data = resp.json()
#             except ValueError as e:
#                 raise ConfluenceError("Invalid JSON while listing pages") from e

#             for item in data.get("results", []):
#                 yield {
#                     "id": item.get("id"),
#                     "title": item.get("title"),
#                     "spaceKey": (item.get("space") or {}).get("key"),
#                 }

#             next_rel = (data.get("_links") or {}).get("next")
#             if not next_rel:
#                 break

#             q = parse_qs(urlparse(next_rel).query)
#             for k, v in q.items():
#                 params[k] = v[0] if isinstance(v, list) and v else v

#     # List Pages in space
#     def list_pages_in_space(self, 
#                             space_key: str, 
#                             limit: int = 50):
#         params = {"type": "page", "spaceKey": space_key, "limit": max(1, min(limit, 200))}
#         path = "rest/api/content"

#         while True:
#             resp = self._get(path, params=params)
#             try:
#                 data = resp.json()
#             except ValueError as e:
#                 raise ConfluenceError(f"Invalid JSON while listing space={space_key}") from e

#             for item in data.get("results", []):
#                 yield {
#                     "id": item.get("id"),
#                     "title": item.get("title"),
#                     "spaceKey": space_key,
#                 }

#             next_rel = (data.get("_links") or {}).get("next")
#             if not next_rel:
#                 break

#             q = parse_qs(urlparse(next_rel).query)
#             for k, v in q.items():
#                 params[k] = v[0] if isinstance(v, list) and v else v

#     # 4) Children of a page (no recursion)
#     def get_children_pages(self, parent_id: str, limit: int = 200) -> list[dict]:
#         params = {"limit": max(1, min(limit, 200))}
#         resp = self._get(f"rest/api/content/{parent_id}/child/page", params=params)

#         try:
#             data = resp.json()
#         except ValueError as e:
#             raise ConfluenceError(f"Invalid JSON while listing children for {parent_id}") from e

#         return [{"id": item.get("id"), "title": item.get("title")} for item in data.get("results", [])]
    
#     def build_page_tree(self, 
#                         page_id: str,
#                          max_depth: int | None = None) -> dict:
        
#         root = self.get_page(page_id, include_body=False)
#         node = {"id": root["id"], "title": root["title"], "children": []}

#         if max_depth == 0:
#             return node

#         try:
#             children = self.get_children_pages(page_id)
#         except ConfluenceNotFound:
#             return node

#         for child in children:
#             node["children"].append(
#                 self.build_page_tree(
#                     child["id"],
#                     None if max_depth is None else max_depth - 1,
#                 )
#             )
#         return node
    
#     def flatten_tree_to_list(self, node: dict, acc: list) -> list:
#         """
#         Recursively flatten the tree into a list of [id, title].
#         """
#         acc.append([node.get("id"), node.get("title")])
#         for child in node.get("children", []):
#             self.flatten_tree_to_list(child, acc)
#         return acc

    
#     @staticmethod
#     def print_tree(node: dict, indent: int = 0) -> None:
#         print("  " * indent + f"- {node.get('title', '(no title)')} (id={node.get('id')})")
#         for child in node.get("children", []):
#             ConfluenceLoader.print_tree(child, indent + 1)

