class ConfluenceError(Exception):
    """Generic Confluence error """

class ConfluenceAuthError(ConfluenceError):
    """401/403 authentication/authorization issues."""

class ConfluenceNotFound(ConfluenceError):
    """404 not found."""

class ConfluenceRateLimited(ConfluenceError):
    """429 rate limit hit and retries exhausted."""

class ConfluenceServerError(ConfluenceError):
    """5xx after retries."""