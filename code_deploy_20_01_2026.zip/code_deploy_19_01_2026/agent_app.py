import os
import json
from dotenv import load_dotenv
import streamlit as st
from agents.rag_agent import create_agentic_rag
from utils.common import read_yaml_config

from pipelines.data_ingestion import dataingestion_pipeline
from utils.azure_models import get_azure_models

import mlflow

load_dotenv()

# Set MLflow tracking URI first, before any other MLflow operations
# Wrap in try-except to handle connection issues gracefully
try:
    mlflow.set_tracking_uri(os.getenv("MLFLOW_TRACKING_URI", "http://localhost:5000"))
    mlflow.set_experiment("RAGTraces-16-Jan-Agent")
    mlflow.langchain.autolog()
    print("✓ MLflow tracking enabled")
except Exception as e:
    print(f"⚠ MLflow tracking disabled due to: {e}")
    # Continue without MLflow tracking
config = read_yaml_config()
embeddings, chat_model = get_azure_models(config)
agent= create_agentic_rag()


def query_agent(question:str, max_iterations:int=2):

    initial_state = {
                "question": question,
                "query_analysis": None,
                "sub_queries": [],
                "retrieved_docs": [],
                "relevance_score": None,
                "current_answer": "",
                "final_answer": None,
                "iteration": 0,
                "evaluation_result": None,
                "max_iterations": max_iterations
                        }
    result = agent.invoke(initial_state)
    return result


def main(): 
    st.set_page_config(page_title="RAG Chatbot", layout="wide")
    st.title("RAG Chatbot")

    st.sidebar.header("Data Ingestion")

    data_source = st.sidebar.selectbox(
        "Select Data Source",
        options=["Local Data", "MCP Server", "Confluence Server"],
        index=0
    )

    ingest_clicked = st.sidebar.button("Ingest Data")

    if ingest_clicked:
        if data_source == "Local Data":
            st.sidebar.warning(
                "Local data ingestion is Removed."
            )

        elif data_source == "MCP Server":
            st.sidebar.warning(
                "MCP Server ingestion is not implemented yet."
            )

        elif data_source == "Confluence Server":
            with st.spinner("Processing and Storing the chunks...."):
                ingestor= dataingestion_pipeline(config)
                ingestor.main()

    if "messages" not in st.session_state:
        st.session_state.messages = []

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    user_input = st.chat_input("Ask me about the document...")
    if user_input:
        st.session_state.messages.append(
            {"role": "user", "content": user_input}
        )
        with st.chat_message("user"):
            st.markdown(user_input)

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                response=query_agent(question=user_input)
                print(response)
                final_ans= response.get("final_answer")
                answer= final_ans.answer
                confidence= final_ans.confidence
                reasoning= final_ans.reasoning
                retrieved_chunks = response.get("retrieved_docs")
                evaluation_result= response.get('evaluation_result')

            msg= f"""{answer} \n\n Confidence: {str(confidence)} \n\n  Reasoning: {reasoning} \n\n Evaluation Agent Result: \n\n Answer Relevancy: {evaluation_result.answer_relevancy} \n\n Context Precision: {evaluation_result.context_precision} \n\n Faithfulness: {evaluation_result.faithfulness}"""

            st.markdown(msg)

            if retrieved_chunks:
                with st.expander("🔍 Retrieved Chunks"):
                    for i, chunk in enumerate(retrieved_chunks, start=1):
                        st.markdown(
                            f"""**Chunk {i}:** {chunk['chunk_text']}"""
                        )

        st.session_state.messages.append(
            {"role": "assistant", "content": answer}
        )

if __name__ == "__main__":
    main()
