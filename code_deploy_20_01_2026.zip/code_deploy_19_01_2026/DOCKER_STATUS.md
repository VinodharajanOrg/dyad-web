# 🎉 Docker Setup Complete and Running!

## ✅ Current Status

All services are successfully running:

| Service | Status | Port | Access URL |
|---------|--------|------|------------|
| PostgreSQL | ✅ Healthy | 5432 | localhost:5432 |
| MLflow | ✅ Running | 5001 | http://localhost:5001 |
| Streamlit App | ✅ Healthy | 8501 | http://localhost:8501 |

## ⚠️ Important Notes

### Port Change
**MLflow is running on port 5001 (not 5000)**
- **Reason**: Port 5000 was already in use by Control Center on your system
- **Solution**: Changed external port mapping to 5001→5000
- **Impact**: Access MLflow UI at http://localhost:5001 instead of http://localhost:5000

### Fixed Issues
1. ✅ **PostgreSQL pgvector extension** - Made optional in init-db.sql
2. ✅ **MLflow port conflict** - Changed to port 5001
3. ✅ **MLflow security headers** - Added `--allowed-hosts='*'` for Docker networking
4. ✅ **App MLflow URI** - Updated to use environment variable
5. ✅ **Docker compose version warning** - Removed obsolete version field

## 🚀 Quick Access

Open these URLs in your browser:

### Streamlit Application
```
http://localhost:8501
```
This is your main RAG chatbot interface.

### MLflow UI
```
http://localhost:5001
```
View experiment tracking and model metrics.

## 📋 Next Steps

### 1. Add Your Documents
```bash
# Place .docx files in the input data directory
cp your-document.docx data/input_data/
```

### 2. Ingest Data
1. Open http://localhost:8501
2. Click "Ingest Data" button in the left sidebar
3. Wait for processing to complete
4. You'll see confirmation messages for each file

### 3. Start Querying
- Type your questions in the chat input
- The system will retrieve relevant chunks and generate answers
- Retrieved chunks are shown in an expandable section

## 🛠️ Management Commands

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f rag-app
docker-compose logs -f mlflow
docker-compose logs -f postgres
```

### Check Status
```bash
docker-compose ps
```

### Restart Services
```bash
# Restart all
docker-compose restart

# Restart specific service
docker-compose restart rag-app
```

### Stop Services
```bash
# Stop (keeps data)
docker-compose down

# Stop and remove volumes (deletes all data)
docker-compose down -v
```

## 🔍 Health Checks

### Manual Health Verification
```bash
# Streamlit
curl http://localhost:8501/_stcore/health
# Should return: ok

# MLflow
curl http://localhost:5001/health
# Should return: OK

# PostgreSQL
docker-compose exec postgres pg_isready -U postgres
# Should return: postgres:5432 - accepting connections
```

## 📊 Resource Usage

Check Docker resource usage:
```bash
docker stats
```

Expected resource usage:
- **PostgreSQL**: ~50-100MB RAM
- **MLflow**: ~200-300MB RAM
- **Streamlit App**: ~500MB-1GB RAM
- **Total**: ~1-1.5GB RAM

## 🐛 Troubleshooting

### Services Not Responding
```bash
# Check if containers are running
docker-compose ps

# Check logs for errors
docker-compose logs --tail=50
```

### Port Already in Use
If you see "port already in use" errors:
```bash
# Check what's using the port
lsof -i :8501  # or :5001, :5432

# Kill the process or change port in docker-compose.yml
```

### Database Connection Errors
```bash
# Verify PostgreSQL is healthy
docker-compose ps postgres

# Check PostgreSQL logs
docker-compose logs postgres

# Test connection
docker-compose exec postgres psql -U postgres -c "SELECT 1"
```

### MLflow Not Accessible
```bash
# Check if MLflow is running
docker-compose ps mlflow

# View MLflow logs
docker-compose logs mlflow --tail=100

# Test health endpoint
curl http://localhost:5001/health
```

### Application Errors
```bash
# Check application logs
docker-compose logs rag-app --tail=100

# Restart application
docker-compose restart rag-app

# Verify environment variables
docker-compose exec rag-app env | grep -E "(AZURE|MLFLOW|PGSQL)"
```

## 📝 Configuration Files

All configuration files are mounted as volumes:
- `./data` → Application data (input/output)
- `./config` → Configuration files
- `./.env` → Environment variables

Changes to mounted files take effect after restarting the service:
```bash
docker-compose restart rag-app
```

## 🔄 Updating the Application

### Update Code
```bash
# After making code changes
docker-compose build rag-app
docker-compose up -d rag-app
```

### Update Dependencies
```bash
# Edit pyproject.toml
# Then rebuild
docker-compose build --no-cache rag-app
docker-compose up -d rag-app
```

## 💾 Backup and Restore

### Backup Database
```bash
docker-compose exec -T postgres pg_dump -U postgres postgres > backup_$(date +%Y%m%d).sql
```

### Restore Database
```bash
cat backup_20260109.sql | docker-compose exec -T postgres psql -U postgres postgres
```

## 📈 Monitoring

### View Experiment Tracking
1. Open http://localhost:5001
2. Navigate to "Experiments"
3. Click on "RAGTraces" experiment
4. View runs, metrics, and parameters

### Check Application Metrics
- Response times visible in MLflow traces
- Retrieval metrics tracked per query
- Model performance metrics logged

## 🎯 Production Considerations

For production deployment, consider:

1. **Change ports if needed** - Edit `docker-compose.yml`
2. **Use secrets** - Don't commit `.env` file
3. **Add SSL/TLS** - Use nginx reverse proxy
4. **Scale services** - Use Docker Swarm or Kubernetes
5. **Persistent storage** - Use external volumes
6. **Monitoring** - Add Prometheus + Grafana
7. **Logging** - Centralize with ELK stack

## 📞 Support

If you encounter issues:

1. Check logs: `docker-compose logs -f`
2. Verify environment variables in `.env`
3. Ensure Docker has enough resources (4GB+ RAM)
4. Check disk space: `df -h`
5. Review service health: `docker-compose ps`

## ✨ Success Indicators

You know everything is working when:
- ✅ All three containers show "healthy" or "running" status
- ✅ Streamlit UI loads at http://localhost:8501
- ✅ MLflow UI loads at http://localhost:5001
- ✅ You can click "Ingest Data" without errors
- ✅ Chat responses are generated successfully

---

**Last Updated**: January 9, 2026
**Docker Compose Version**: 2.40.3
**Python Version**: 3.10
**Status**: ✅ All Systems Operational
