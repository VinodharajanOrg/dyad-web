#!/bin/bash

# Pre-flight Check Script for RAG Application Docker Setup
# This script verifies that your system is ready to run the Docker environment

set -e

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "=========================================="
echo "RAG Application - Pre-flight Check"
echo "=========================================="
echo ""

# Track overall status
ERRORS=0
WARNINGS=0

# Check 1: Docker installed
echo -n "Checking Docker installation... "
if command -v docker &> /dev/null; then
    DOCKER_VERSION=$(docker --version | awk '{print $3}' | sed 's/,//')
    echo -e "${GREEN}✓${NC} Found Docker $DOCKER_VERSION"
else
    echo -e "${RED}✗${NC} Docker not found"
    echo "  → Install Docker from https://www.docker.com/get-started"
    ERRORS=$((ERRORS + 1))
fi

# Check 2: Docker Compose installed
echo -n "Checking Docker Compose... "
if command -v docker-compose &> /dev/null; then
    COMPOSE_VERSION=$(docker-compose --version | awk '{print $4}' | sed 's/,//' || echo "unknown")
    echo -e "${GREEN}✓${NC} Found Docker Compose $COMPOSE_VERSION"
elif docker compose version &> /dev/null; then
    COMPOSE_VERSION=$(docker compose version --short 2>/dev/null || echo "unknown")
    echo -e "${GREEN}✓${NC} Found Docker Compose (plugin) $COMPOSE_VERSION"
else
    echo -e "${RED}✗${NC} Docker Compose not found"
    echo "  → Install Docker Compose"
    ERRORS=$((ERRORS + 1))
fi

# Check 3: Docker daemon running
echo -n "Checking Docker daemon... "
if docker info &> /dev/null; then
    echo -e "${GREEN}✓${NC} Docker daemon is running"
else
    echo -e "${RED}✗${NC} Docker daemon not running"
    echo "  → Start Docker Desktop or Docker service"
    ERRORS=$((ERRORS + 1))
fi

# Check 4: .env file exists
echo -n "Checking .env file... "
if [ -f .env ]; then
    echo -e "${GREEN}✓${NC} Found .env file"
    
    # Check if .env has required variables
    REQUIRED_VARS=("AZURE_INFERENCE_ENDPOINT" "AZURE_INFERENCE_KEY" "PGSQL_PASS")
    for VAR in "${REQUIRED_VARS[@]}"; do
        if grep -q "^${VAR}=" .env && ! grep -q "^${VAR}=\"\"" .env && ! grep -q "^${VAR}=$" .env; then
            echo -e "  ${GREEN}✓${NC} $VAR is set"
        else
            echo -e "  ${YELLOW}!${NC} $VAR is empty or not set"
            WARNINGS=$((WARNINGS + 1))
        fi
    done
else
    echo -e "${YELLOW}!${NC} .env file not found"
    echo "  → Run: cp .env.example .env"
    echo "  → Then edit .env with your credentials"
    WARNINGS=$((WARNINGS + 1))
fi

# Check 5: Ports available
echo -n "Checking port availability... "
PORTS=(5432 5000 8501)
PORT_ISSUES=0
for PORT in "${PORTS[@]}"; do
    if lsof -Pi :$PORT -sTCP:LISTEN -t &> /dev/null; then
        if [ $PORT_ISSUES -eq 0 ]; then
            echo ""
        fi
        echo -e "  ${YELLOW}!${NC} Port $PORT is already in use"
        WARNINGS=$((WARNINGS + 1))
        PORT_ISSUES=$((PORT_ISSUES + 1))
    fi
done
if [ $PORT_ISSUES -eq 0 ]; then
    echo -e "${GREEN}✓${NC} All required ports are available"
fi

# Check 6: Disk space
echo -n "Checking disk space... "
if command -v df &> /dev/null; then
    AVAILABLE_GB=$(df -BG . | awk 'NR==2 {print $4}' | sed 's/G//')
    if [ "$AVAILABLE_GB" -ge 10 ]; then
        echo -e "${GREEN}✓${NC} ${AVAILABLE_GB}GB available"
    else
        echo -e "${YELLOW}!${NC} Only ${AVAILABLE_GB}GB available (recommend 10GB+)"
        WARNINGS=$((WARNINGS + 1))
    fi
else
    echo -e "${YELLOW}!${NC} Cannot check disk space"
fi

# Check 7: Memory available
echo -n "Checking available memory... "
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    TOTAL_MEM_GB=$(sysctl -n hw.memsize | awk '{print int($1/1024/1024/1024)}')
    echo -e "${GREEN}✓${NC} ${TOTAL_MEM_GB}GB total system memory"
    if [ "$TOTAL_MEM_GB" -lt 4 ]; then
        echo -e "  ${YELLOW}!${NC} Less than 4GB RAM (minimum requirement)"
        WARNINGS=$((WARNINGS + 1))
    fi
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux
    TOTAL_MEM_GB=$(free -g | awk '/^Mem:/{print $2}')
    echo -e "${GREEN}✓${NC} ${TOTAL_MEM_GB}GB total system memory"
    if [ "$TOTAL_MEM_GB" -lt 4 ]; then
        echo -e "  ${YELLOW}!${NC} Less than 4GB RAM (minimum requirement)"
        WARNINGS=$((WARNINGS + 1))
    fi
else
    echo -e "${YELLOW}!${NC} Cannot check memory on this OS"
fi

# Check 8: Config files exist
echo -n "Checking configuration files... "
CONFIG_FILES=("config/config.yml" "pyproject.toml")
CONFIG_OK=true
for FILE in "${CONFIG_FILES[@]}"; do
    if [ ! -f "$FILE" ]; then
        if $CONFIG_OK; then
            echo ""
            CONFIG_OK=false
        fi
        echo -e "  ${RED}✗${NC} Missing: $FILE"
        ERRORS=$((ERRORS + 1))
    fi
done
if $CONFIG_OK; then
    echo -e "${GREEN}✓${NC} All config files present"
fi

# Check 9: Data directory exists
echo -n "Checking data directory... "
if [ -d "data/input_data" ]; then
    FILE_COUNT=$(find data/input_data -type f -name "*.docx" 2>/dev/null | wc -l | tr -d ' ')
    echo -e "${GREEN}✓${NC} data/input_data exists ($FILE_COUNT .docx files)"
else
    echo -e "${YELLOW}!${NC} data/input_data directory not found"
    echo "  → Create it: mkdir -p data/input_data"
    WARNINGS=$((WARNINGS + 1))
fi

# Summary
echo ""
echo "=========================================="
echo "Summary"
echo "=========================================="

if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
    echo -e "${GREEN}✓ All checks passed!${NC}"
    echo ""
    echo "You're ready to start the application:"
    echo "  ./docker-helper.sh start"
    echo ""
    echo "or:"
    echo "  docker-compose up -d --build"
    exit 0
elif [ $ERRORS -eq 0 ]; then
    echo -e "${YELLOW}! $WARNINGS warning(s) found${NC}"
    echo ""
    echo "You can still run the application, but review the warnings above."
    echo ""
    echo "To start:"
    echo "  ./docker-helper.sh start"
    exit 0
else
    echo -e "${RED}✗ $ERRORS error(s) found${NC}"
    if [ $WARNINGS -gt 0 ]; then
        echo -e "${YELLOW}! $WARNINGS warning(s) found${NC}"
    fi
    echo ""
    echo "Please fix the errors above before running the application."
    exit 1
fi
