#!/bin/bash

# Docker Helper Script for RAG Application
# This script provides convenient commands for managing the Docker environment

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if .env file exists
check_env_file() {
    if [ ! -f .env ]; then
        print_warning ".env file not found!"
        print_info "Creating .env from .env.example..."
        if [ -f .env.example ]; then
            cp .env.example .env
            print_warning "Please edit .env file and add your credentials before running the application"
            exit 1
        else
            print_error ".env.example not found!"
            exit 1
        fi
    fi
}

# Function to start services
start_services() {
    print_info "Starting all services..."
    docker-compose up -d --build
    print_info "Services started successfully!"
    print_info "Streamlit App: http://localhost:8501"
    print_info "MLflow UI: http://localhost:5001"
    print_info "PostgreSQL: localhost:5432"
}

# Function to stop services
stop_services() {
    print_info "Stopping all services..."
    docker-compose down
    print_info "Services stopped successfully!"
}

# Function to view logs
view_logs() {
    if [ -z "$1" ]; then
        print_info "Viewing logs for all services..."
        docker-compose logs -f
    else
        print_info "Viewing logs for $1..."
        docker-compose logs -f "$1"
    fi
}

# Function to check status
check_status() {
    print_info "Checking service status..."
    docker-compose ps
}

# Function to restart services
restart_services() {
    print_info "Restarting services..."
    docker-compose restart
    print_info "Services restarted successfully!"
}

# Function to run tests
run_tests() {
    print_info "Running tests..."
    docker-compose exec rag-app python -m pytest "$@"
}

# Function to access shell
access_shell() {
    print_info "Opening shell in rag-app container..."
    docker-compose exec rag-app bash
}

# Function to cleanup
cleanup() {
    print_warning "This will remove all containers, volumes, and images!"
    read -p "Are you sure? (yes/no): " confirm
    if [ "$confirm" = "yes" ]; then
        print_info "Cleaning up..."
        docker-compose down -v --rmi all
        print_info "Cleanup completed!"
    else
        print_info "Cleanup cancelled"
    fi
}

# Function to backup database
backup_db() {
    BACKUP_FILE="backup_$(date +%Y%m%d_%H%M%S).sql"
    print_info "Backing up database to $BACKUP_FILE..."
    docker-compose exec -T postgres pg_dump -U postgres postgres > "$BACKUP_FILE"
    print_info "Backup completed: $BACKUP_FILE"
}

# Function to restore database
restore_db() {
    if [ -z "$1" ]; then
        print_error "Please provide backup file: ./docker-helper.sh restore <backup_file>"
        exit 1
    fi
    if [ ! -f "$1" ]; then
        print_error "Backup file not found: $1"
        exit 1
    fi
    print_warning "This will restore database from $1"
    read -p "Are you sure? (yes/no): " confirm
    if [ "$confirm" = "yes" ]; then
        print_info "Restoring database..."
        cat "$1" | docker-compose exec -T postgres psql -U postgres postgres
        print_info "Database restored successfully!"
    else
        print_info "Restore cancelled"
    fi
}

# Main menu
show_help() {
    cat << EOF
Docker Helper Script for RAG Application

Usage: ./docker-helper.sh [command]

Commands:
    start           Start all services (build if necessary)
    stop            Stop all services
    restart         Restart all services
    status          Show service status
    logs [service]  View logs (optionally for specific service)
    test [args]     Run tests inside container
    shell           Open bash shell in app container
    backup          Backup PostgreSQL database
    restore <file>  Restore PostgreSQL database from backup
    cleanup         Remove all containers, volumes, and images
    help            Show this help message

Services:
    rag-app         Streamlit application
    mlflow          MLflow tracking server
    postgres        PostgreSQL database

Examples:
    ./docker-helper.sh start
    ./docker-helper.sh logs rag-app
    ./docker-helper.sh test tests/unit/test_embedding.py
    ./docker-helper.sh backup
    ./docker-helper.sh restore backup_20260109_120000.sql

EOF
}

# Main script logic
case "$1" in
    start)
        check_env_file
        start_services
        ;;
    stop)
        stop_services
        ;;
    restart)
        restart_services
        ;;
    status)
        check_status
        ;;
    logs)
        view_logs "$2"
        ;;
    test)
        shift
        run_tests "$@"
        ;;
    shell)
        access_shell
        ;;
    cleanup)
        cleanup
        ;;
    backup)
        backup_db
        ;;
    restore)
        restore_db "$2"
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        print_error "Unknown command: $1"
        show_help
        exit 1
        ;;
esac
