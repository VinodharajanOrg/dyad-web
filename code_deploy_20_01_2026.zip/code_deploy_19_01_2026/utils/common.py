import os
import yaml
from pathlib import Path
import logging

def read_yaml_config(file_path=os.path.join("config", "config.yml")):
    """
    Read a YAML file and return its content as a dictionary.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Config file not found: {file_path}")
    
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f)
        return config
    except Exception as e:
        print(f"Error reading YAML file: {e}")
        return None

# def setup_logging(LOG_FILE):
#     """Configures the root logger for file and console output."""
#     logger = logging.getLogger()
#     logger.setLevel(logging.INFO)

#     # Prevent duplicate handlers if the function is called multiple times
#     if logger.hasHandlers():
#         logger.handlers.clear()

#     # 1. File Handler (for permanent record)
#     file_handler = logging.FileHandler(LOG_FILE, mode='a')
#     file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(name)s - %(message)s')
#     file_handler.setFormatter(file_formatter)
#     logger.addHandler(file_handler)

#     # 2. Console Handler (for real-time feedback)
#     console_handler = logging.StreamHandler()
#     console_formatter = logging.Formatter('[%(levelname)s] %(message)s')
#     console_handler.setFormatter(console_formatter)
#     logger.addHandler(console_handler)

#     logger.info(f"Logging configured. Outputting to console and '{LOG_FILE}'")
#     return logger

