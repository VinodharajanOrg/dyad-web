import psycopg2
import numpy as np
from dotenv import load_dotenv
from psycopg2 import sql
from typing import Dict, List, Any
from psycopg2 import sql
import numpy as np
import json
import streamlit as st

load_dotenv()

# @st.cache_resource
def get_postgres_connection(config:dict, password:str):
    """
    Create and return a PostgreSQL connection and cursor using config.yaml.
    """
    try:
        if config is None:
            print("Failed to read DB config.")
            return None, None

        db_conf = config.get("database", {})
     
        conn = psycopg2.connect(
            host=db_conf.get("host", "localhost"),
            port=int(db_conf.get("port", 5432)),
            dbname=db_conf.get("dbname", "postgres"),
            user=db_conf.get("user", "postgres"),
            password= password
        )
  
        cursor = conn.cursor()
        cursor.execute("SELECT version();")
        version = cursor.fetchone()

        return conn, cursor
    
    except Exception as e:
        print(f"Failed to connect to PostgreSQL: {e}")
        return None, None
    
## create table 
def create_table_if_not_exist(conn, cursor, 
                              table_name: str, 
                              schema: str = "public"):
    """Create the schema (if not exists) and table (if not exists) with safe, unique constraints.
    """

    try:

        cursor.execute(
            sql.SQL("CREATE SCHEMA IF NOT EXISTS {schema};")
            .format(schema=sql.Identifier(schema))
        )
        conn.commit()

        pk_name = f"{schema}_{table_name}_pkey"
        unique_name = f"{schema}_{table_name}_unique_chunk"

        create_table_query = sql.SQL("""
            CREATE TABLE IF NOT EXISTS {schema}.{table} (
                id INT NOT NULL GENERATED ALWAYS AS IDENTITY,
                file_name VARCHAR(255) NOT NULL,
                chunk_text TEXT NOT NULL,
                embedding REAL[] NOT NULL,
                metadata JSONB DEFAULT '{{}}'::jsonb,
                page_id TEXT,  
                chunk_tsv TSVECTOR,                                            
                CONSTRAINT {pk} PRIMARY KEY (id),
                CONSTRAINT {unique} UNIQUE (file_name, chunk_text)
            );
        """).format(
            schema=sql.Identifier(schema),
            table=sql.Identifier(table_name),
            pk=sql.Identifier(pk_name),
            unique=sql.Identifier(unique_name)
        )

        cursor.execute(create_table_query)
        conn.commit()
        return True

    except Exception as e:
        conn.rollback()
        raise e

def insert_data(conn, cursor, schema, table_name, data: dict):
    try:
        if not isinstance(data, dict):
            raise ValueError("Data must be a dictionary")

        chunk_text = data.get("chunk_text")
        if not chunk_text:
            raise ValueError("chunk_text is required")

        metadata = json.dumps(data.get("metadata")) if data.get("metadata") else None
        embedding = data.get("embedding")
        file_name= data.get('file_name')
        page_id= data.get("page_id")

        query = sql.SQL("""
            INSERT INTO {schema}.{table}
            (file_name, chunk_text, embedding, metadata,page_id, chunk_tsv)
            VALUES (%s, %s, %s, %s, %s, to_tsvector('english', %s))
            ON CONFLICT (file_name, chunk_text) DO NOTHING;
            """).format(
                schema=sql.Identifier(schema),
                table=sql.Identifier(table_name)
            )

        cursor.execute(
            query,
            (file_name, chunk_text, embedding, metadata, page_id, chunk_text)
        )
        conn.commit()
        return True

    except Exception as e:
        conn.rollback()
        raise e

def retrieve_data_query_b(
    cursor,
    schema: str,
    table_name: str,
    user_query: str,
    top_k: int = 3,
    threshold: float = 0.0
) -> List[Dict[str, Any]]:
    """
    PostgreSQL FTS retriever - Query B 
    """

    if not isinstance(user_query, str) or not user_query.strip():
        raise ValueError("user_query must be a non-empty string.")

    if not isinstance(top_k, int) or top_k < 1:
        raise ValueError("top_k must be a positive integer.")

    if not isinstance(threshold, (int, float)):
        raise ValueError("threshold must be a number.")
    

    retriever_query = sql.SQL("""
        WITH query AS (
            SELECT websearch_to_tsquery('english', %s) AS q
        )
        SELECT id,
               chunk_text,
               ts_rank_cd(chunk_tsv, q) AS rank,
                file_name,
                metadata
        FROM {schema}.{table}, query
        WHERE ts_rank_cd(chunk_tsv, q) >= %s
        ORDER BY rank DESC
        LIMIT %s;
    """).format(
        schema=sql.Identifier(schema),
        table=sql.Identifier(table_name)
    )

    cursor.execute(retriever_query, (user_query, threshold, top_k))
    rows = cursor.fetchall()

    if not rows:
        return []

    return [
        {
            "id": row[0],
            "chunk_text": row[1],
            "score": float(row[2]),
            "file_name": row[3],
            "metadata": row[4]

        }
        for row in rows
    ]

def keywrod_retriever_plaintotsquery(
    cursor,
    schema: str,
    table_name: str,
    user_query: str,
    top_k: int = 3,
    threshold: float = 0.0
) -> List[Dict[str, Any]]:
    """
    PostgreSQL FTS retriever - Query A (STRICT MATCH)
    """

    if not isinstance(user_query, str) or not user_query.strip():
        raise ValueError("user_query must be a non-empty string.")

    if not isinstance(top_k, int) or top_k < 1:
        raise ValueError("top_k must be a positive integer.")

    if not isinstance(threshold, (int, float)):
        raise ValueError("threshold must be a number.")

    retriever_query = sql.SQL("""
        SELECT id,
               chunk_text,
               ts_rank(
                 to_tsvector('english', chunk_text),
                 plainto_tsquery('english', %s)
               ) AS rank,
                file_name,
                metadata
        FROM {schema}.{table}
        WHERE ts_rank(
                to_tsvector('english', chunk_text),
                plainto_tsquery('english', %s)
              ) >= %s
        ORDER BY rank DESC
        LIMIT %s;
    """).format(
        schema=sql.Identifier(schema),
        table=sql.Identifier(table_name)
    )

    cursor.execute(retriever_query, (user_query, user_query, threshold, top_k))
    rows = cursor.fetchall()

    if not rows:
        return []

    return [
        {
            "id": row[0],
            "chunk_text": row[1],
            "score": float(row[2]),
            "file_name": row[3],
            "metadata": row[4]
        }
        for row in rows
    ]

def semantic_retrieve_data(
                cursor,
                schema: str,
                table_name: str,
                query_embedding: List[float],
                top_k: int = 3
            ) -> List[Dict[str, Any]]:


    if not isinstance(query_embedding, (list, tuple)) or len(query_embedding) == 0:
        raise ValueError("query_embedding must be a non-empty list/tuple of floats.")

    try:
        q_emb = np.asarray(query_embedding, dtype=float)
    except (TypeError, ValueError):
        raise ValueError("query_embedding must contain numeric values.")

    if np.isnan(q_emb).any():
        raise ValueError("query_embedding contains NaN values.")
    if np.linalg.norm(q_emb) == 0:
        raise ValueError("query_embedding must be non-zero (norm > 0).")

    if not isinstance(top_k, int) or top_k < 1:
        raise ValueError("top_k must be a positive integer.")

    retriever_query = sql.SQL(
        "SELECT id, chunk_text, embedding, file_name, metadata FROM {schema}.{table};"
    ).format(
        schema=sql.Identifier(schema),
        table=sql.Identifier(table_name),
    )

    cursor.execute(retriever_query)
    rows = cursor.fetchall()

    if not rows:
        return []  # No data in DB

    #Compute cosine similarity
    similarities: List[tuple] = []

    for row in rows:
        # Expecting columns: id, chunk_text, embedding
        id, chunk_text, embedding, file_name, metadata = row

        if embedding is None:
            # Skip rows without an embedding
            continue

        try:
            emb = np.asarray(embedding, dtype=float)
        except (TypeError, ValueError):
            continue

        if emb.ndim != 1 or emb.size == 0 or np.isnan(emb).any():
            continue

        if emb.shape != q_emb.shape:
            continue

        denom = np.linalg.norm(q_emb) * np.linalg.norm(emb)
        if denom == 0: # Skip zero norm embeddings
            continue

        sim = float(np.dot(q_emb, emb) / denom)
        similarities.append((id, sim, chunk_text, file_name, metadata)) #cosine similariies

    if not similarities:
        return []  # No valid similarities computed

    # Select top_k by similarity (descending)
    similarities.sort(key=lambda x: x[1], reverse=True)
    top_chunks = [{"id": id, 
                   "chunk_text": text, 
                   "similarity": sim,
                   "file_name": file_name,
                   "metadata": metadata} for id, sim, text, file_name, metadata in similarities[:top_k]]
    return top_chunks


