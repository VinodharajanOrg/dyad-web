from typing import List, Dict
from utils.db_utils import (get_postgres_connection, 
                            keywrod_retriever_plaintotsquery, 
                            semantic_retrieve_data
                            )

# import streamlit as st


def unique_by_id(items):
    seen=set() 
    unique=[]

    for item in items:
        if item['id'] not in seen:
            seen.add(item['id'])
            unique.append(item)

    return unique

def postgres_retriever(user_query: str, 
                       config:dict, 
                       password:str, 
                       embeddings ) -> List[Dict]:
    """
    Retrieves top-k relevant chunks from Postgres DB based on query embeddings.
    """
    # conn, cursor = get_postgres_connection(config, os.getenv("PGSQL_PASS"))
    conn, cursor = get_postgres_connection(config, password)

    query_embedding = embeddings.embed_query(user_query)
    

    semantic_retrieved_chunks = semantic_retrieve_data(cursor, config['database']['schema'], 
                                     config['database']['table_name'], query_embedding, top_k=3
                                        )
    
    ## keyword search -A
    keyword_searched_chunks= keywrod_retriever_plaintotsquery(cursor, schema=config['database']['schema'], 
                                                 table_name= config['database']['table_name'], 
                                                user_query= user_query, 
                                                top_k= config['retriever']['keywordsearch_params']['limit'], 
                                                threshold=config['retriever']['keywordsearch_params']['threshould'])
    

    combined_result= semantic_retrieved_chunks + keyword_searched_chunks

    ## get the unique chunks
    combined_result= unique_by_id(items=combined_result)

    return combined_result if combined_result else []