import os
import streamlit as st
from langchain_azure_ai.embeddings import AzureAIEmbeddingsModel
from langchain_azure_ai.chat_models import AzureAIChatCompletionsModel
from langchain_openai import AzureChatOpenAI
from azure.core.credentials import AzureKeyCredential


# @st.cache_resource
def get_azure_models(cfg):
    try:
        cred= AzureKeyCredential(os.getenv("AZURE_INFERENCE_KEY"))
        embeddings= AzureAIEmbeddingsModel(
            endpoint= os.getenv('AZURE_INFERENCE_ENDPOINT'), 
            credential=cred, 
            model=cfg['models']['AZURE_EMBED_MODEL']
        )

        chat_model = AzureChatOpenAI(
                        azure_deployment=cfg['models']['AZURE_CHAT_MODEL'],
                        api_version="2024-08-01-preview",
                        temperature=0, 
                        api_key=os.getenv('AZURE_INFERENCE_KEY'),
                        azure_endpoint=os.getenv('AZURE_INFERENCE_ENDPOINT').replace("models", "")
                        )
        return embeddings, chat_model
    
    except Exception as e:
        raise e