# Docker Setup Guide for RAG Application

This guide explains how to run the RAG (Retrieval-Augmented Generation) application in a Docker environment.

## Architecture Overview

The application consists of three main services:
1. **PostgreSQL Database** - Stores document chunks and embeddings
2. **MLflow Server** - Tracks experiments and model metrics
3. **Streamlit App** - RAG chatbot user interface

## Prerequisites

- Docker Engine 20.10+ installed
- Docker Compose V2+ installed
- At least 4GB of available RAM
- Azure AI credentials (endpoint and API key)

## Quick Start

### 1. Setup Environment Variables

Create a `.env` file in the project root:

```bash
cp .env.example .env
```

Edit `.env` and fill in your credentials:

```env
AZURE_INFERENCE_ENDPOINT="your-azure-endpoint"
AZURE_INFERENCE_KEY="your-azure-api-key"
MLFLOW_TRACKING_URI="http://mlflow:5001"
PGSQL_PASS="your-postgres-password"
```

### 2. Prepare Configuration

Verify `config/config.yml` has the correct database settings:

```yaml
database:
  host: "postgres"  # Use service name in Docker
  port: 5432
  dbname: "postgres"
  user: "postgres"
  table_name: "rag_chunks"
  schema: "public"
```

### 3. Build and Start Services

```bash
# Build and start all services
docker-compose up -d --build

# Check service status
docker-compose ps

# View logs
docker-compose logs -f
```

### 4. Access the Application

- **Streamlit App**: http://localhost:8501
- **MLflow UI**: http://localhost:5001
- **PostgreSQL**: localhost:5432

### 5. Ingest Data

1. Place your `.docx` files in the `data/input_data` directory
2. Open the Streamlit app at http://localhost:8501
3. Click the "Ingest Data" button in the sidebar
4. Wait for processing to complete

### 6. Start Chatting

Ask questions about your ingested documents in the chat interface!

## Docker Commands Reference

### Start Services
```bash
# Start all services in background
docker-compose up -d

# Start specific service
docker-compose up -d rag-app

# Start with build
docker-compose up -d --build
```

### Stop Services
```bash
# Stop all services
docker-compose down

# Stop and remove volumes (deletes data)
docker-compose down -v

# Stop specific service
docker-compose stop rag-app
```

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f rag-app
docker-compose logs -f mlflow
docker-compose logs -f postgres

# Last 100 lines
docker-compose logs --tail=100
```

### Restart Services
```bash
# Restart all
docker-compose restart

# Restart specific service
docker-compose restart rag-app
```

### Execute Commands in Container
```bash
# Open bash in app container
docker-compose exec rag-app bash

# Run pytest
docker-compose exec rag-app python -m pytest

# Check Python version
docker-compose exec rag-app python --version
```

### Check Service Health
```bash
# View service status
docker-compose ps

# Check health of specific service
docker inspect --format='{{json .State.Health}}' rag-streamlit-app
```

## Running Tests in Docker

```bash
# Run all tests
docker-compose exec rag-app python -m pytest

# Run specific test file
docker-compose exec rag-app python -m pytest tests/unit/test_embedding.py

# Run with verbose output
docker-compose exec rag-app python -m pytest -v

# Run with coverage
docker-compose exec rag-app python -m pytest --cov=. tests/
```

## Data Persistence

The setup uses Docker volumes for data persistence:

- `postgres_data` - PostgreSQL database files
- `mlflow_data` - MLflow artifacts and models
- `./data` - Mounted as volume for input/output data

Data persists even when containers are stopped. To completely remove data:

```bash
docker-compose down -v
```

## Troubleshooting

### Service Won't Start

```bash
# Check logs
docker-compose logs service-name

# Rebuild image
docker-compose build --no-cache service-name
docker-compose up -d service-name
```

### Database Connection Issues

```bash
# Verify PostgreSQL is running
docker-compose ps postgres

# Check PostgreSQL logs
docker-compose logs postgres

# Test connection
docker-compose exec postgres psql -U postgres -c "SELECT 1"
```

### MLflow Not Accessible

```bash
# Check MLflow logs
docker-compose logs mlflow

# Verify port binding
docker-compose port mlflow 5000

# Test health endpoint
curl http://localhost:5001/health
```

### Application Errors

```bash
# View application logs
docker-compose logs -f rag-app

# Check environment variables
docker-compose exec rag-app env | grep AZURE

# Restart application
docker-compose restart rag-app
```

### Out of Memory

```bash
# Check resource usage
docker stats

# Increase Docker Desktop memory allocation
# Docker Desktop > Settings > Resources > Memory
```

### Port Already in Use

```bash
# Check what's using the port
lsof -i :8501  # On macOS/Linux
netstat -ano | findstr :8501  # On Windows

# Change port in docker-compose.yml
# postgres:
#   ports:
#     - "5433:5432"  # Change host port
```

## Configuration Updates

To update configuration without rebuilding:

1. Edit `config/config.yml`
2. Restart the service:
```bash
docker-compose restart rag-app
```

To update environment variables:

1. Edit `.env` file
2. Restart services:
```bash
docker-compose down
docker-compose up -d
```

## Production Deployment

For production deployment, consider:

1. **Use secrets management**:
   ```bash
   docker secret create azure_key azure_key.txt
   ```

2. **Set resource limits**:
   ```yaml
   rag-app:
     deploy:
       resources:
         limits:
           cpus: '2'
           memory: 4G
         reservations:
           cpus: '1'
           memory: 2G
   ```

3. **Enable restart policies**:
   ```yaml
   rag-app:
     restart: unless-stopped
   ```

4. **Use production WSGI server** (modify Dockerfile):
   ```dockerfile
   CMD ["gunicorn", "--bind", "0.0.0.0:8501", "app:server"]
   ```

5. **Setup reverse proxy** (nginx) for SSL/TLS

## Backup and Restore

### Backup PostgreSQL Database
```bash
docker-compose exec postgres pg_dump -U postgres postgres > backup.sql
```

### Restore PostgreSQL Database
```bash
cat backup.sql | docker-compose exec -T postgres psql -U postgres postgres
```

### Backup Volumes
```bash
docker run --rm -v rag-feature-retriever-update-2_postgres_data:/data \
  -v $(pwd):/backup alpine tar czf /backup/postgres_backup.tar.gz /data
```

## Cleanup

### Remove Stopped Containers
```bash
docker-compose rm
```

### Remove Unused Images
```bash
docker image prune -a
```

### Complete Cleanup
```bash
docker-compose down -v --rmi all
docker system prune -a --volumes
```

## Support

For issues or questions:
1. Check logs: `docker-compose logs -f`
2. Verify environment variables are set correctly
3. Ensure Docker daemon is running
4. Check disk space: `df -h`
5. Review Docker resource allocation

## Additional Resources

- [Docker Documentation](https://docs.docker.com/)
- [Docker Compose Reference](https://docs.docker.com/compose/compose-file/)
- [Streamlit Documentation](https://docs.streamlit.io/)
- [MLflow Documentation](https://mlflow.org/docs/latest/index.html)
